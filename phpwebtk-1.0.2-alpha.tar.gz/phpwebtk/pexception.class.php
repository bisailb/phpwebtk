<?php
/**
 * $Id: pexception.class.php,v 1.2 2004/09/09 03:11:03 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class PException
 *
 * This class is responsible for exception handling and inherits from the
 * internal Exception class.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage debugging
 */
class PException extends Exception {
    /**
     * function Display
     *
     * This method formats the error message appropriately and displays it.
     *
     * @access public
     * @param Exception Exception object
     * @static
     */
    public static function Display(Exception $Exception) {
        print($Exception->getMessage() . ' on line <strong>' . $Exception->getLine() . '</strong>.<hr />');
    }
}
?>