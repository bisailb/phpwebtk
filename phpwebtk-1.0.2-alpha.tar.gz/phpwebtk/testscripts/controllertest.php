<?
require_once('../configuration/constants.php');
function __autoload($class) {
    require_once(CLASS_PATH . strtolower($class) . '.class.php');
}
$start = microtime(1);
ob_start();
$Client = Client::GetInstance();
$Client->SendRequest();
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('<br />Time Elapsed: ' . $time);
?>