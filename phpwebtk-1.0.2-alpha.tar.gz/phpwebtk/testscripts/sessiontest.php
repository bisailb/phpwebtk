<?php
require_once('../configuration/constants.php');
function __autoload($class) {
    require_once(CLASS_PATH . strtolower($class) . '.class.php');
}
$start = microtime(1);
ob_start();
$Session = Session::GetInstance();
$Session->OpenSession();
print('Congratulations! Your new session has started.');
$Session->CloseSession();
print('<br />Goodbye! Your session has ended.');
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('<br />Time Elapsed: ' . $time);
?>