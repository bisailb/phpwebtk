<?php
require_once('../configuration/constants.php');
function __autoload($class) {
    require_once(CLASS_PATH . strtolower($class) . '.class.php');
}
$start = microtime(1);
ob_start();
$plaintext = 'what do ya want for nothing?';
$Digest = Digest::GetInstance();
$ciphertext = $Digest->GetDigest($plaintext);
print('Digest: ' . $ciphertext);
print('<br />Plaintext: ' . $plaintext);
if (FALSE !== $Digest->IsValidDigest($ciphertext, $plaintext)) {
    print('<br />Signature Valid');
} else {
    print('<br />Invalid Signature');
}
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('<br />Time Elapsed: '. $time);
?>