<?php
/**
 * $Id: xmldaofactory.class.php,v 1.4 2004/09/09 03:11:02 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class XmlDaoFactory
 *
 * This class implements the DAO Factory's operations that create concrete XML
 * Data Access Objects (DAOs).
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage databases
 */
class XmlDaoFactory extends PException {
    // Private members
    private static $XmlDaoFactory;
    /**
     * function GetInstance
     *
     * This method instantiates a new object from this class; more
     * specifically, it's a singleton instance.
     *
     * @access public
     * @static
     * @return XmlDaoFactory object instance
     */
    public static function GetInstance() {
        $XmlDaoFactory = null;
        if (empty(XmlDaoFactory::$XmlDaoFactory)) {
            XmlDaoFactory::$XmlDaoFactory = new XmlDaoFactory();
        }
        return(XmlDaoFactory::$XmlDaoFactory);
    }
    /**
     * function LoadXmlFile
     *
     * This method loads XML from a file, validates its associated XML Schema
     * and optionally preserves white space.
     *
     * @access public
     * @param fileName XML file
     * @param schemaName XML Schema file
     * @param whiteSpace Preserve white space
     * @return DomDocument object instance
     */
    public function LoadXmlFile($fileName, $schemaName, $whiteSpace=FALSE) {
        $Exception = null;
        try {
            if (file_exists($fileName)) {
                $DomDocument = new DomDocument();
                try {
                    if (TRUE !== $DomDocument->load($fileName)) {
                        throw new Exception('<h1>XML Parse</h1><strong>Fatal:</strong> $DomDocument->load(): Error while parsing ' . $fileName . ': phpwebtk.databases.XmlDaoFactory.Exception');
                    } else {
                        try {
                            if (TRUE !== $DomDocument->schemaValidate($schemaName)) {
                                throw new Exception('<h1>XML Schema Parse</h1><strong>Fatal:</strong> $DomDocument->schemaValidate(): Invalid Schema: phpwebtk.databases.XmlDaoFactory.Exception');
                            }
                        } catch (Exception $Exception) {
                            PException::Display($Exception);
                        }
                        $DomDocument->preserveWhiteSpace = $whiteSpace;
                    }
                } catch (Exception $Exception) {
                    PException::Display($Exception);
                }
            } else {
                throw new Exception('<h1>No such file or directory</h1><strong>Fatal:</strong> file_exists(): Failed to open ' . $fileName . ': phpwebtk.databases.XmlDaoFactory.Exception');
            }
        } catch (Exception $Exception) {
            PException::Display($Exception);
        }
        return($DomDocument);
    }
    /**
     * function GetXmlDao
     *
     * The GetXmlDao method creates a new object of class XmlConfigDao.
     *
     * @access public
     * @param DomDocument DomDocument object
     * @return XmlConfigDao object instance
     */
    public function GetXmlDao(DomDocument $DomDocument) {
        return(XmlConfigDao::GetInstance($DomDocument));
    }
}
?>