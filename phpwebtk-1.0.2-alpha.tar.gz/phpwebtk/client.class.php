<?php
/**
 * $Id: client.class.php,v 1.2 2004/08/31 04:27:43 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class Client
 *
 * This class is responsible for building a Request object and sending the
 * Request object to the front controller for processing. The front controller
 * then gives the response back to the end user.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage http
 */
class Client extends Controller {
    // Private members
    private static $Client;
    private $Request;
    /**
     * function GetInstance
     *
     * This method instantiates a new object from this class; more
     * specifically, it's a singleton instance.
     *
     * @access public
     * @static
     * @return Client object instance
     */
    public static function GetInstance() {
        $Client = null;
        if (empty(Client::$Client)) {
            Client::$Client = new Client();
        }
        return(Client::$Client);
    }
    /**
     * function BuildRequest
     *
     * This method constructs, retrieves and shares the Request object to this
     * class locally so that it can be sent to the front controller via the
     * SendRequest method for processing.
     *
     * @access private
     */
    private function BuildRequest() {
        $RequestDirector = RequestDirector::GetInstance();
        $HttpRequestBuilder = HttpRequestBuilder::GetInstance();
        $RequestDirector->ConstructRequest($HttpRequestBuilder);
        $this->Request = $HttpRequestBuilder->GetRequest();
    }
    /**
     * function SendRequest
     *
     * This method builds and sends the Request object to the front controller
     * via the ProcessRequest method for processing. The front controller then
     * gives a response back to the end user.
     *
     * @access public
     */
    public function SendRequest() {
        $this->BuildRequest();
        $Controller = Controller::GetInstance();
        $Controller->ProcessRequest($this->Request);
    }
}
?>