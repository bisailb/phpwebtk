<?php
/**
 * $Id: controller.class.php,v 1.4 2004/09/09 03:17:13 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class Controller
 *
 * This class serves as a single entry point for handling all requests in the
 * system. The front controller is responsible for delegating processes to
 * various handlers while minimizing the coupling among these components by
 * implementing flexible request handling mechanisms, and managing the choice
 * of the next view to present to the end user.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage http
 */
class Controller extends PException {
    // Private members
    private static $Controller;
    /**
     * function GetInstance
     *
     * This method instantiates a new object from this class; more
     * specifically, it's a singleton instance.
     *
     * @access public
     * @static
     * @return Controller object instance
     */
    public static function GetInstance() {
        $Controller = null;
        if (TRUE !== Controller::$Controller) {
            Controller::$Controller = new Controller();
        }
        return(Controller::$Controller);
    }
    /**
     * function ProcessRequest
     *
     * This method initiates a session to preserve specific information across
     * subsequent requests; adds or strips slashes from the HTTP GET or HTTP
     * POST information; executes customized operations; and transfers the
     * modified Request object to the Dispatch method along with the name of
     * the view to present to the end user.
     *
     * @access protected
     * @param Request Request object
     */
    protected function ProcessRequest(Request $Request) {
        $Session = Session::GetInstance();
        $Session->OpenSession();
        $HttpRequestHandler = new HttpRequestHandler();
        //$HttpRequestHandler->setSuccessor($SomeOtherHandler);
        $HttpRequestHandler->HandleRequest($Request);
        $Receiver = new View();
        $Command = new ViewCommand($Receiver);
        $Invoker = new Invoker();
        $Invoker->SetCommand($Command);
        $viewName = $Invoker->ExecuteCommand($Request);
        $this->Dispatch($Request, $viewName);
        $Session->CloseSession();
    }
    /**
     * function Dispatch
     *
     * This method is responsible for view management and navigation. The
     * dispatcher provides a dynamic dispatching mechanism to manager the
     * choice of the next view to present to the end user.
     *
     * @access private
     * @param Request Request object
     * @param viewName View name for the class-based view
     */
    private function Dispatch(Request $Request, $viewName) {
            $View = new $viewName();
            $View->Display();
    }
}
?>