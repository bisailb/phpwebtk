<?php
/**
 * $Id: command.class.php,v 1.1 2004/09/09 03:16:21 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class Command
 *
 * This class declares an interface for executing an operation.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage http
 */
abstract class Command {
    // Abstract Methods
    public abstract function Execute(Request $Request);
}
?>