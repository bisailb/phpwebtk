<?php
/**
 * $Id: mysqltdaofactory.class.php,v 1.2 2004/08/30 21:46:32 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class MysqltDaoFactory
 *
 * This class implements the DaoFactory's operations that create concrete MySQL
 * Data Access Objects (DAOs).
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage databases
 */
class MysqltDaoFactory extends DaoFactory {
    // Private members
    private $dsn;
    // Protected members
    protected $Database;
    /**
     * function __construct
     *
     * This method is executed when an object is instantiated from this class.
     * Preprocessing can be done here before the object is put into service.
     *
     * @access public
     */
    public function __construct($dsn) {
        $this->dsn = $dsn;
    }
    /**
     * function CreateConnection
     *
     * This method creates a database connection object using the provided Data
     * Source Name (DSN).
     *
     * @access public
     * @param dsn Data Source Name (DSN)
     * @return Database object instance
     * @static
     */
    public static function CreateConnection($dsn) {
       $Database = NewAdoConnection($dsn);
       return($Database);
    }
    /**
     * function GetSampleDao
     *
     * This method creates a new object of class MysqltSampleDao.
     *
     * @access public
     * @return MysqltSampleDao object instance
     */
    public function GetSampleDao() {
        return(new MysqltSampleDao($this->dsn));
    }
}
?>