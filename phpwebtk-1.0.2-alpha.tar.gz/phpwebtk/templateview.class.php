<?PHP
/**
 * $Id: templateview.class.php,v 1.1 2004/08/30 21:50:06 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class TemplateView
 *
 * This class represents and displays information to the end user. The
 * information that is used in a dynamic display is retrieved from a model.
 * Handlers support views by encapsulating and adapting a model for use in
 * a display.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage templates
 */
class TemplateView {
    /**
     * function Display
     *
     * This method displays the complete view to the user.
     *
     * @access public
     * @static
     */
    public function Display() {
        print("Hello World!<br />");
    }
}
?>