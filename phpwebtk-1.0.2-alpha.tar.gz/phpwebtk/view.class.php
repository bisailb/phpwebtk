<?php
/**
 * $Id: view.class.php,v 1.1 2004/09/09 03:16:21 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class View
 *
 * This class knows how to perform the operation(s) associated with carrying
 * out the request.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage http
 */
class View extends PException {
    /**
     * function Action
     *
     * This method defines the operation(s) to be executed by the invoker.
     *
     * @access private
     */
    public function Action(Request $Request) {
        if (!empty($Request->HTTP_GET['page'])) {
            try {
                if (file_exists(CLASS_PATH . $Request->HTTP_GET['page'] . 'view.class.php')) {
                    return($Request->HTTP_GET['page'] . 'view');
                } else {
                    throw new Exception('<h1>Not Found</h1><strong>Notice:</strong> Action(): The requested view does not exist. : phpwebtk.http.View.Exception at <strong>');
                }
            } catch (Exception $Exception) {
                PException::Display($Exception);
            }
        } else {
            header('Location: http://' . $Request->HTTP_HOST . dirname($Request->REQUEST_URI) . '/controllertest.php?action=view&page=template');
        }
    }
}
?>