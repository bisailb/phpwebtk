<?php
/**
 * $Id: streamio.class.php,v 1.5 2004/09/09 03:11:03 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.2 Alpha
 *
 * @package phpwebtk
 */
/**
 * class StreamIO
 *
 * This class provides stream input and output operations and supports
 * buffering for write operations. PHP will search for a protocol handler
 * (also known as a wrapper) for schemes in the form of "scheme://...".
 * unless URL-aware fopen wrappers and other wrappers are disabled.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage filesandfolders
 */
class StreamIo extends PException {
    // Private members
    private static $StreamIo;
    /**
     * function GetInstance
     *
     * This method instantiates a new object from this class; more
     * specifically, it's a singleton instance.
     *
     * @access public
     * @static
     * @return StreamIo object instance
     */
    public static function GetInstance() {
        $StreamIo = null;
        if (empty(StreamIo::$StreamIo)) {
            StreamIo::$StreamIo = new StreamIo();
        }
        return(StreamIo::$StreamIo);
    }
    /**
     * function Read
     *
     * This method opens a file and reads all bytes from the file pointer
     * (binary-safe).
     *
     * @access public
     * @param fileName File to open
     * @param mode Type of access
     * @return string File contents
     */
    public function &Read($fileName, $mode) {
        $Exception = null;
        try {
            if (FALSE !== ($handle = fopen($fileName, $mode))) {
                $buffer = fread($handle, filesize($fileName));
                fclose($handle);
            } else {
                throw new Exception('<h1>File Not Found or Permission Denied</h1><strong>Warning:</strong> read(): Failed to open stream ' . $fileName . ': phpwebtk.filesfolders.StreamIo.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            PException::Display($Exception);
        }
        return($buffer);
    }
    /**
     * function ReadLength
     *
     * This method opens a file and reads a specific number of bytes from the
     * file pointer (binary-safe).
     *
     * @access public
     * @param fileName File to open
     * @param length Length in bytes
     * @param mode Type of access
     * @return string File contents
     */
    public function &ReadLength($fileName, $length, $mode) {
        $Exception = null;
        try {
            if (FALSE !== ($handle = fopen($fileName, $mode))) {
                $buffer = fread($handle, $length);
                fclose($handle);
            } else {
                throw new Exception('<h1>File Not Found or Permission Denied</h1><strong>Warning:</strong> readLength(): Failed to open stream ' . $fileName . ': phpwebtk.filesfolders.StreamIo.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            PException::Display($Exception);
        }
        return($buffer);
    }
    /**
     * function ReadStream
     *
     * This method opens a URL and reads all bytes from the file pointer
     * (binary-safe).
     *
     * @access public
     * @param stream Stream to open
     * @param mode Type of access
     * @return string Stream contents
     */
    public function &ReadStream($stream, $mode) {
        $Exception = null;
        try {
            if (FALSE !== ($handle = fopen($stream, $mode))) {
                $buffer = fread($handle, filesize($stream));
                fclose($handle);
            } else {
                throw new Exception('<h1>URL Not Found or Permission Denied</h1><strong>Warning:</strong> read(): Failed to open stream ' . $stream . ': phpwebtk.filesfolders.StreamIo.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            PException::Display($Exception);
        }
        return($buffer);
    }
    /**
     * function ReadStreamLength
     *
     * This method opens a URL and reads a specific number of bytes from the
     * file pointer (binary-safe).
     *
     * @access public
     * @param stream Stream to open
     * @param length Length in bytes
     * @param mode Type of access
     * @return string Stream contents
     */
    public function &ReadStreamLength($stream, $length, $mode) {
        $Exception = null;
        try {
            $buffer = '';
            if (FALSE !== ($handle = fopen($stream, $mode))) {
                while (!feof($handle)) {
                    $buffer .= fread($handle, $length);
                }
                fclose($handle);
            } else {
                throw new Exception('<h1>URL Not Found or Permission Denied</h1><strong>Warning:</strong> readLength(): Failed to open stream ' . $stream . ': phpwebtk.filesfolders.StreamIo.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            PException::Display($Exception);
        }
        return($buffer);
    }
    /**
     * function Write
     *
     * This method opens a file or URL and writes bytes to the file pointer
     * (binary-safe).
     *
     * @access public
     * @param fileName Stream to open
     * @param data Data to write
     */
    public function write($fileName, $data) {
        $Exception = null;
        try {
            if (FALSE !== ($handle = fopen($fileName, 'wb'))) {
                try {
                    if (FALSE !== fwrite($handle, $data)) {
                        fclose($handle);
                    } else {
                        throw new Exception('<h1>Invalid File Handle</h1><strong>Warning:</strong> fwrite(): Invalid stream resource: phpwebtk.filesfolders.StreamIo.Exception at <strong>');
                    }
                }
                catch (Exception $Exception) {
                    PException::Display($Exception);
                }
            } else {
                throw new Exception('<h1>File Not Found or Permission Denied</h1><strong>Warning:</strong> fopen(): Failed to open stream ' . $fileName . ': phpwebtk.filesfolders.StreamIo.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            PException::Display($Exception);
        }
    }
}
?>