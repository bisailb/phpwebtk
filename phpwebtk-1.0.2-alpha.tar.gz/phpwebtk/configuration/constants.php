<?php
// Disable the "Run SQL" link for the web-based UI for performance monitoring
define('ADODB_PERF_NO_RUN_SQL', 0);
// Class path where all classes can be found
define('CLASS_PATH', '/path/to/apache/share/htdocs/phpwebtk/');
// Path to the XML configuration file
define('CONFIG_FILE', CLASS_PATH.'configuration/phpwebtk.xml');
// Path to the XML Schema for the XML configuration file
define('SCHEMA_FILE', CLASS_PATH.'configuration/phpwebtk.xsd');
// Path to required dependencies
require_once(CLASS_PATH.'adodb/adodb.inc.php');
?>