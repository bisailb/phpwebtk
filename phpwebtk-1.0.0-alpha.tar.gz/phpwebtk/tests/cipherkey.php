<?php

function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
}

$filename = '../config.xml';
$key = 'This is a sample key.';

$Crypt =& new Crypt($filename);
$Crypt->setCipherKey($key);

?>
