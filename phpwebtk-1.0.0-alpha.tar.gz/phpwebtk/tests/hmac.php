<?php

function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
}

$filename = '../config.xml';
$plaintext = 'what do ya want for nothing?';

$Hash = new Hash($filename);

$ciphertext = $Hash->getHmac($plaintext);
print('<br />SHA-256 HMAC: ' . $ciphertext);
print('<br />Plaintext: ' . $plaintext);

if (!$Hash->isValidHmac($ciphertext, $plaintext)) {
    print('<br />Invalid Signature');
} else {
    print('<br />Signature Valid');
}

?>
