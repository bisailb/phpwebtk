<?php

function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
}

$filename = '../config.xml';
$plaintext = 'what do ya want for nothing?';

$Crypt = new Crypt($filename);

$ciphertext = $Crypt->encrypt($plaintext);
print('<br />AES-256 Ciphertext: ' . $ciphertext);

$output = $Crypt->decrypt($ciphertext);
print('<br />Plaintext: ' . $output);

?>
