<?php

function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
}

$filename = '../config.xml';

$Session = new Session($filename);

$Session->startSession();
print('Congratulations! Your new session has started.');

$Session->endSession();
print('<br />Goodbye! Your session has ended.');

?>
