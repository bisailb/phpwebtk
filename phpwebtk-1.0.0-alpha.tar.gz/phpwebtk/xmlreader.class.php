<?php
/** 
 * $Id: xmlreader.class.php,v 1.1 2004/08/07 05:18:28 bbisaillon Exp $
 * XML formats parsing and generation
 *
 * @package phpwebtk
 */
/** 
 * class XmlReader
 *
 * The XmlReader is responsible for reading parameters from an XML
 * file and making them available to an application.
 *
 * This class may be used with multiple XML files as it uses a constructor to
 * load the XML file to interpret and XPath to query XML nodes.
 *
 * @package phpwebtk.xml
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 */
class XmlReader {
    private $DomDocument;
    private $DomXpath;
    private $DomNodeList;
    private $DomElement;
    /** 
     * function __construct
     *
     * This is a constructor that loads an XML file into an object of class
     * DomDocument.
     *
     * @access public
     * @param filename - XML file to interpret
     */
    public function __construct($filename) {
        if (file_exists($filename)) {
            $this->DomDocument =& new DomDocument();
            if (!$this->DomDocument->load($filename)) {
                exit('Fatal: Error while parsing ' . $filename);
            }
            $this->DomDocument->preserveWhiteSpace = false;
        } else {
            exit('Fatal: Failed to open ' . $filename);
        }
    }
    /** 
     * function __destruct
     *
     * This is a destructor that destroys members of this class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->DomDocument, $this->XPathContext, $this->DomNodeList, $this->DomElement);
    }
    /** 
     * function getElementsByPath
     *
     * Query an XML document for a specific node(s) matching some criteria and
     * return a collection of elements and their associated values.
     *
     * @access public
     * @param expression - XPath expression
     * @param prefix - Namespace prefix
     * @param uri - Namespace URI
     * @param noprefix - Strip namespace prefixes (optional)
     * @return array
     */
    public function &getElementsByPath($expression, $prefix, $uri, $noprefix=false) {
        $elementList = array();
        $DomXpath =& new DomXpath($this->DomDocument);
        if (!empty($prefix) && !empty($uri)) {
            $DomXpath->registerNamespace($prefix, $uri);
        }
        $DomNodeList = $DomXpath->query($expression);
        if(is_object($DomNodeList) && $DomNodeList->length) {
            foreach ($DomNodeList as $DomElement) {
                if ($noprefix) {
                    $tagName = str_replace($prefix.':', '', $DomElement->tagName);
                    $elementList[$tagName] = $DomElement->textContent;
                } else {
                    $elementList[$DomElement->tagName] = $DomElement->textContent;
                }
            }
        }
        return $elementList;
    }
    /** 
     * function setElementByPath
     *
     * Query an XML document for a specific node matching some criteria and
     * replace the original text content with new text content.
     *
     * @access public
     * @param expression - XPath expression
     * @param prefix - Namespace prefix
     * @param uri - Namespace URI
     * @param textcontent = Text content
     * @param filename = XML file to save
     */
    public function setElementByPath($expression, $prefix, $uri, $textcontent, $filename) {
        $DomXpath =& new DomXpath($this->DomDocument);
        if (!empty($prefix) && !empty($uri)) {
            $DomXpath->registerNamespace($prefix, $uri);
        }
        $DomNodeList = $DomXpath->query($expression);
        if(is_object($DomNodeList) && $DomNodeList->length) {
            foreach ($DomNodeList as $DomElement) { 
                $DomText = $this->DomDocument->createTextNode($textcontent);
                $DomElement->replaceChild($DomText, $DomElement->firstChild);
            }
        }
        $this->DomDocument->save($filename);
    }
}
?>
