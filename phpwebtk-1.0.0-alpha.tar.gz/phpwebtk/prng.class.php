<?php
/** 
 * $Id: prng.class.php,v 1.4 2004/08/07 05:18:28 bbisaillon Exp $
 * Math related classes
 *
 * @package phpwebtk
 */
/** 
 * class Prng
 *
 * This class provides a simple interface to two character devices, the rand()
 * function and the mt_rand() function. The /dev/random character device is
 * suitable for use when very high quality randomness is desired. The
 * /dev/urandom character device will result in randomness that is merely
 * cryptographically strong. The main difference between the two is that
 * /dev/random is blocking and /dev/urandom is non-blocking. The rand()
 * function uses the libc random number generator. However, mt_rand() is a
 * drop-in replacement for rand() that uses a random number generator with
 * known characteristics using the Mersenne Twister, that will produce
 * randomnumbers four times faster than what the average libc rand() provides.
 * 
 * @package phpwebtk.math
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 */
class Prng extends Exception {
    /** 
     * function __construct
     *
     * This is a constructor that does nothing.
     *
     * @access public
     */
    public function __construct() {
    }
    /** 
     * function __destruct
     *
     * This is a destructor that does nothing.
     *
     * @access public
     */
    public function __destruct() {
    }
    /** 
     * function getPseudoRandomValue()
     *
     * Generate a pseudo-random value using a common random number generator.
     *
     * @access public
     * @param prng - Pseudo-random number generator to use
     * @param length - The number of bytes of entropy to return
     * @return string
     */
    public function getPseudoRandomValue($prng, $length=8) {
        switch($prng) {
            case 0:
                $StreamIO =& new StreamIO();
                return $StreamIO->readLength('/dev/random', $length);
                break;
            case 1:
                $StreamIO =& new StreamIO();
                return $StreamIO->readLength('/dev/urandom', $length);
                break;
            case 2:
                return rand();
                break;
            case 3:
                return mt_rand();
                break;
        }
    }
}
?>
