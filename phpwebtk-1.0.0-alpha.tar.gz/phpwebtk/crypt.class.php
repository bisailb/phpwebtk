<?php
/** 
 * $Id: crypt.class.php,v 1.4 2004/08/07 05:18:28 bbisaillon Exp $
 * Encrypting, decrypting and hashing data
 *
 * @package phpwebtk
 */
/** 
 * class Crypt
 *
 * This class provides a simple interface to the mcrypt library. It can be 
 * used to encrypt and decrypt data. mcrypt was chosen because it supports a
 * wide variety of block algorithms and cipher modes. For a complete list of
 * supported algorithms and modes refer to the documentation of mcrypt.
 * 
 * @package phpwebtk.cryptography
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 */
class Crypt extends Exception {
    private $filename;
    private $XmlReader;
    private $encryptionDescriptor;
    private $initializationVector;
    private $randomDevice;
    private $blockAlgorithm;
    private $blockAlgorithmMode;
    private $cipherKey;
    /** 
     * function __construct
     *
     * This is a constructor that creates a new object of class XmlReader
     * with the XML file to load as its only parameter. Furthermore, XPath is
     * used to query XML nodes and store values from a configuration file into
     * private members of this class for further usage by other functions.
     *
     * @access public
     * @param filename - XML file to open
     */
    public function __construct($filename) {
        $this->filename = $filename;
        $this->XmlReader =& new XmlReader($this->filename);
        $elementList =& $this->XmlReader->getElementsByPath('//crypt:*', 'crypt', 'http://sourceforge.net/projects/phpwebtk', true);
        $this->randomDevice = $elementList['randomDevice'];
        $this->blockAlgorithm = $elementList['blockAlgorithm'];
        $this->blockAlgorithmMode = $elementList['blockAlgorithmMode'];
        $this->cipherKey = $elementList['cipherKey'];
    }
    /** 
     * function __destruct
     *
     * This is a destructor that destroys the private member variables of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->encryptionDescriptor, $this->initializationVector, $this->randomDevice, $this->blockAlgorithm, $this->blockAlgorithmMode, $this->cipherKey);
    }
    /** 
     * function getIvSize
     *
     * Get the size of the Initialization Vector (IV) of the opened algorithm.
     *
     * @access private
     * @return integer
     */
    private function getIvSize() {
        return mcrypt_enc_get_iv_size($this->encryptionDescriptor);
    }
    /** 
     * function getKeySize
     *
     * Get the maximum supported key size of the opened mode.
     *
     * @access private
     * @return integer
     */
    private function getKeySize() {
        return mcrypt_enc_get_key_size($this->encryptionDescriptor);
    }
    /** 
     * function getBlockSize
     *
     * Get the block size of the opened algorithm.
     *
     * @access private
     * @return integer
     */
    private function getBlockSize() {
        return mcrypt_enc_get_block_size($this->encryptionDescriptor);
    }
    /** 
     * function openModule
     *
     * Opens the module of the algorithm and the mode to be used.
     *
     * @access private
     * @return integer|false
     */
    private function openModule() {
        try {
            if (FALSE != ($this->encryptionDescriptor = mcrypt_module_open($this->blockAlgorithm, '', $this->blockAlgorithmMode, ''))) {
            } else {
                throw new Exception('Warning: openModule(): The module of the algorithm and the mode to be used failed to open because an unknown error occurred. Initialization failed in ');
            }
        }
        catch (Exception $Exception) {
            exit($Exception->getMessage() . $Exception->getFile() . ' on line ' . $Exception->getLine() . '.' . "\n");
        }
    }
    /** 
     * function getRandomIv
     *
     * Get initialization vector (IV) from the registered session.
     *
     * @access private
     * @return string
     */
    private function getRandomIv() {
        if (isset($_SESSION['randomIv']) && !empty($_SESSION['randomIv'])) {
            $this->initializationVector = base64_decode($_SESSION['randomIv']);
        }
        return $this->initializationVector;
    }
    /** 
     * function setRandomIv
     *
     * Create an initialization vector (IV) from a random source and store it
     * in the registered session.
     *
     * @access private
     * @return string
     */
    private function setRandomIv() {
        if (isset($_SESSION['randomIv']) && !empty($_SESSION['randomIv'])) {
            $this->initializationVector = base64_decode($_SESSION['randomIv']);
        } else {
            $this->initializationVector = mcrypt_create_iv($this->getIvSize(), $this->randomDevice);
            $_SESSION['randomIv'] = base64_encode($this->initializationVector);
        }
        return $this->initializationVector;
    }
    /** 
     * function setCipherKey
     *
     * Create cipher key according to the maximum supported key size of the
     * opened mode.
     *
     * @access public
     * @param plaintext - Plaintext to use as a key
     */
    public function setCipherKey($plaintext) {
        $elementList =& $this->XmlReader->getElementsByPath('//prng:*', 'prng', 'http://sourceforge.net/projects/phpwebtk', true);
        $randomDevice = $elementList['randomDevice'];
        $Prng =& new Prng();
        $Hash =& new Hash($this->filename);
        $this->openModule();
        $salt = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabchefghjkmnpqrstuvwxyz0123456789';
        for ($i = 0; $i < $this->getKeySize(); $i++) {
            $number = $Prng->getPseudoRandomValue($randomDevice) % 59;
            $tmpPlaintext = substr($salt, $number, 1);
            $plaintext = $plaintext . $tmpPlaintext;
        }
        $this->cipherKey = $Hash->getHmac($plaintext);
        $this->XmlReader->setElementByPath('//crypt:cipherKey', 'crypt', 'http://sourceforge.net/projects/phpwebtk', $this->cipherKey, $this->filename);
        $this->closeModule();
        return $this->cipherKey;
    }
    /** 
     * function encrypt
     *
     * Initialize all buffers needed for encryption, encrypt data and
     * deinitialize an encryption module.
     *
     * @access public
     * @return string
     */
    public function encrypt($plaintext) {
        $this->openModule();
        $cipherKey = substr(base64_decode($this->cipherKey), 0, $this->getKeySize());
        mcrypt_generic_init($this->encryptionDescriptor, $cipherKey, $this->setRandomIv());
        $ciphertext = mcrypt_generic($this->encryptionDescriptor, $plaintext);
        mcrypt_generic_deinit($this->encryptionDescriptor);
        $this->closeModule();
        return bin2hex($ciphertext);
    }
    /** 
     * function decrypt
     *
     * Initialize all buffers needed for decryption, decrypt data and
     * deinitialize a decryption module.
     *
     * @access public
     * @return string
     */
    public function decrypt($ciphertext) {
        $this->openModule();
        $cipherKey = substr(base64_decode($this->cipherKey), 0, $this->getKeySize());
        mcrypt_generic_init($this->encryptionDescriptor, $cipherKey, $this->getRandomIv());
        $plaintext = mdecrypt_generic($this->encryptionDescriptor, substr($this->hex2bin($ciphertext), 0, $this->getIvSize()));
        mcrypt_generic_deinit($this->encryptionDescriptor);
        $this->closeModule();
        return trim($plaintext);
    }
    /** 
     * function closeModule
     *
     * Close the mcrypt module.
     *
     * @access public
     */
    private function closeModule() {
        mcrypt_module_close($this->encryptionDescriptor);
    }
    /** 
     * function hex2bin
     *
     * Convert hexadecimal data into a binary string.
     *
     * @access private
     * @param hexdata - Hexadecimal data to convert
     * @return string
     */
    private function hex2bin($hexdata) {
        $length = strlen($hexdata);
        return pack('H' . $length, $hexdata);
    }
}
?>
