<?php
/**
 * $Id: streamio.class.php,v 1.3 2004/08/07 05:18:28 bbisaillon Exp $
 * Listing, accessing and manipulating files and folders
 *
 * @package phpwebtk
 */
/**
 * class StreamIO
 *
 * This class provides stream input and output operations and supports
 * buffering for write operations. PHP will search for a protocol handler
 * (also known as a wrapper) for schemes in the form of "scheme://...".
 * unless URL-aware fopen wrappers and other wrappers are disabled.
 * 
 * @package phpwebtk.filesandfolders
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 */
class StreamIO extends Exception {
    /**
     * function __construct
     *
     * This is a constructor that does nothing.
     *
     * @access public
     */
    public function __construct() {
    }
    /**
     * function __destruct
     *
     * This is a destructor that does nothing.
     *
     * @access public
     */
    public function __destruct() {
    }
    /**
     * function read
     *
     * Open file or URL and read all bytes from the file pointer (binary-safe).
     *
     * @access public
     * @param filename - The stream to open
     * @return string
     */
    public function read($filename) {
        try {
            if (FALSE !== ($handle = fopen($filename, 'rb'))) {
                $contents = fread($handle, filesize($length));
                fclose($handle);
                return $contents;
            } else {
                throw new Exception('<br /><h1>Not Found</h1><strong>Warning:</strong> read(): Failed to open stream ' . $filename . ': phpwebtk.filesfolders.StreamIO.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            echo($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . ':' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
        }        
    }
    /**
     * function readLength
     *
     * Open file or URL and read a specific number of bytes from the file
     * pointer (binary-safe).
     *
     * @access public
     * @param filename - The stream to open
     * @param length - The number of bytes to return
     * @return string
     */
    public function readLength($filename, $length) {
        try {
            if (FALSE !== ($handle = fopen($filename, 'rb'))) {
                $contents = fread($handle, $length);
                fclose($handle);
                return $contents;
            } else {
                throw new Exception('<br /><h1>Not Found</h1><strong>Warning:</strong> readLength(): Failed to open stream ' . $filename . ': phpwebtk.filesfolders.StreamIO.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            echo($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . ':' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
        }        
    }
    /**
     * function write
     *
     * Open file or URL and write bytes to the file pointer (binary-safe).
     *
     * @access public
     * @param filename - The stream to open
     * @param contents - The string contents to write to the stream
     * @return string
     */
    public function write($filename, $contents) {
        try {
            if (FALSE !== ($handle = fopen($filename, 'wb'))) {
                try {
                    if (FALSE !== fwrite($handle, $contents)) {
                        fclose($handle);
                    } else {
                        throw new Exception('<br /><h1>Permission Denied</h1><strong>Warning:</strong> write(): Failed to open stream ' . $filename . ': phpwebtk.filesfolders.StreamIO.Exception at <strong>');
                    }
                }            
                catch (Exception $Exception) {
                    echo($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . '</strong> on line <strong>' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
                }
            } else {
                throw new Exception('<br /><h1>Not Found</h1><strong>Warning:</strong> write(): Failed to open stream ' . $filename . ': phpwebtk.filesfolders.StreamIO.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            echo($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . ':' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
        }        
    }
}
?>
