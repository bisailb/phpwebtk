<?php
/** 
 * $Id: hash.class.php,v 1.4 2004/08/07 05:18:28 bbisaillon Exp $
 * Encrypting, decrypting and hashing data
 *
 * @package phpwebtk
 */
/** 
 * class Hash
 *
 * This class provides a simple interface to the mhash library. It can be
 * used to create both salted and unsalted message digests and message
 * authentication codes. mhash was chosen because it supports a wide
 * variety of hash algorithms. For a complete list of supported hashes,
 * refer to the documentation of mhash.
 * 
 * @package phpwebtk.cryptography
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 */
class Hash extends Exception {
    private $filename;
    private $XmlReader;
    private $saltedS2kAlgorithm;
    private $digestAlgorithm;
    private $digestAlgorithmBlockSize;
    private $hmacAlgorithm;
    private $hmacAlgorithmBlockSize;
    private $randomDevice;
    private $secretKey;
    /** 
     * function __construct
     *
     * This is a constructor that creates a new object of class XmlReader
     * with the XML file to load as its only parameter. Furthermore, XPath is
     * used to query XML nodes and store values from a configuration file into
     * private members of this class for further usage by other functions.
     *
     * @access public
     */
    public function __construct($filename) {
        $this->filename = $filename;
        $this->XmlReader =& new XmlReader($this->filename);
        $elementList =& $this->XmlReader->getElementsByPath('//hash:*', 'hash', 'http://sourceforge.net/projects/phpwebtk', true);
        $this->saltedS2kAlgorithm = $elementList['saltedS2kAlgorithm'];
        $this->digestAlgorithm = $elementList['digestAlgorithm'];
        $this->digestAlgorithmBlockSize = $this->getBlockSize($this->digestAlgorithm);
        $this->hmacAlgorithm = $elementList['hmacAlgorithm'];
        $this->hmacAlgorithmBlockSize = $this->getBlockSize($this->hmacAlgorithm);
        $this->randomDevice = $elementList['randomDevice'];
        $this->secretKey = $elementList['secretKey'];
    }
    /** 
     * function __destruct
     *
     * This is a destructor that destroys the private member variables of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->saltedS2kAlgorithm, $this->digestAlgorithm, $this->digestAlgorithmBlockSize, $this->hmacAlgorithm, $this->hmacAlgorithmBlockSize, $this->secretKey);
    }
    /** 
     * function getHashInfo
     *
     * Display the hash id, the algorithm and the block size for each hash
     * algorithm supported by the mhash library.
     *
     * @access public
     * @return string
     */
    public function getHashInfo() {
        $hashId = mhash_count();
        print("\n");
        for ($i = 0; $i < $hashId; $i++) {
            if (FALSE != mhash_get_block_size($i)) {
                print('Hash ID: ' . $i . "\n" . 'Algorithm: ' . mhash_get_hash_name($i) . "\n" . 'Output Size: ' . mhash_get_block_size($i) . "\n\n");
            }
        }
    }
    /** 
     * function getBlockSize
     *
     * Get the block size of the specified hash.
     *
     * @access private
     * @param hashId - Hash identifier
     * @return integer|false
     */
    private function getBlockSize($hashId) {
        try {
            if (FALSE != mhash_get_block_size($hashId)) {
                return mhash_get_block_size($hashId);
            } else {
                throw new Exception('Warning: getBlockSize(): The specified hash id ' . $hashId . ' does not exist. Initialization failed in ');
            }
        }
        catch (Exception $Exception) {
            exit($Exception->getMessage() . $Exception->getFile() . ' on line ' . $Exception->getLine() . '.' . "\n");
        }
    }
    /** 
     * function getDigest
     *
     * Generate a salted or unsalted message digest.
     *
     * @access public
     * @param plaintext - Plaintext to encode
     * @return string
     */
    public function getDigest($plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {            
            $salt = mhash_keygen_s2k($this->digestAlgorithm, $plaintext, substr(pack('h*', bin2hex(mhash($this->digestAlgorithm, $this->randomDevice))), 0, 8), 4);
            return base64_encode(mhash($this->digestAlgorithm, $plaintext.$salt).$salt);
        } else {
            return base64_encode(mhash($this->digestAlgorithm, $plaintext));
        }
    }
    /** 
     * function isValidDigest
     *
     * Validate a salted or unsalted message digest.
     *
     * @access public
     * @param ciphertext - Ciphertext to use in comparison
     * @param plaintext - Plaintext to use in comparison
     * @return true|false
     */
    public function isValidDigest($ciphertext, $plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {
            $originalCiphertext = substr(base64_decode($ciphertext), 0, $this->digestAlgorithmBlockSize);
            $salt = substr(base64_decode($ciphertext), $this->digestAlgorithmBlockSize);
            $newCiphertext = mhash($this->digestAlgorithm, $plaintext.$salt);
            return $this->compareCiphertextData($originalCiphertext.$salt, $newCiphertext.$salt);
        } else {
            $originalCiphertext = base64_decode($ciphertext);
            $newCiphertext = mhash($this->digestAlgorithm, $plaintext);
            return $this->compareCiphertextData($originalCiphertext, $newCiphertext);
        }
    }
    /** 
     * function setSecretKey
     *
     * Create a secret key up to the length of the block size of the specified
     * hash, hash the key and then use the resultant length of the hash output
     * as the actual key to HMAC.
     *
     * @access public
     * @param plaintext - Plaintext to use as a key
     * @return string
     */
    public function setSecretKey($plaintext) {
        $elementList =& $this->XmlReader->getElementsByPath('//prng:*', 'prng', 'http://sourceforge.net/projects/phpwebtk', true);
        $randomDevice = $elementList['randomDevice'];
        $Prng =& new Prng();
        $salt = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabchefghjkmnpqrstuvwxyz0123456789';
        for ($i = 0; $i < $this->getBlockSize($this->digestAlgorithm); $i++) {
            $number = $Prng->getPseudoRandomValue($randomDevice) % 59;
            $tmpPlaintext = substr($salt, $number, 1);
            $plaintext = $plaintext . $tmpPlaintext;
        }
        $this->secretKey = base64_encode(mhash_keygen_s2k($this->digestAlgorithm, $plaintext, substr(pack('h*', bin2hex(mhash($this->digestAlgorithm, $Prng->getPseudoRandomValue($randomDevice)))), 0, 8), $this->getBlockSize($this->digestAlgorithm)));
        $this->XmlReader->setElementByPath('//hash:secretKey', 'hash', 'http://sourceforge.net/projects/phpwebtk', $this->secretKey, $this->filename);
        return $this->secretKey;
    }
    /** 
     * function getHmac
     *
     * Generate a salted or unsalted IETF RFC 2104 compliant message
     * authentication code.
     *
     * @access public
     * @param plaintext - Plaintext to encode
     * @return string
     */
    public function getHmac($plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {            
            $salt = mhash_keygen_s2k($this->hmacAlgorithm, $plaintext, substr(pack('h*', bin2hex(mhash($this->hmacAlgorithm, $this->randomDevice))), 0, 8), 4);
            return base64_encode(mhash($this->hmacAlgorithm, $plaintext.$salt, base64_decode($this->secretKey)).$salt);
        } else {
            return base64_encode(mhash($this->hmacAlgorithm, $plaintext, base64_decode($this->secretKey)));
        }
    }
    /** 
     * function isValidHmac
     *
     * Validate a salted or unsalted IETF RFC 2104 compliant message
     * authentication code.
     *
     * @access public
     * @param ciphertext - Ciphertext to use in comparison
     * @param plaintext - Plaintext to use in comparison
     * @return true|false
     */
    public function isValidHmac($ciphertext, $plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {
            $originalCiphertext = substr(base64_decode($ciphertext), 0, $this->hmacAlgorithmBlockSize);
            $salt = substr(base64_decode($ciphertext), $this->hmacAlgorithmBlockSize);            
            $newCiphertext = mhash($this->hmacAlgorithm, $plaintext.$salt, base64_decode($this->secretKey));
            return $this->compareCiphertextData($originalCiphertext.$salt, $newCiphertext.$salt);
        } else {
            $originalCiphertext = base64_decode($ciphertext);
            $newCiphertext = mhash($this->hmacAlgorithm, $plaintext, base64_decode($this->secretKey));
            return $this->compareCiphertextData($originalCiphertext, $newCiphertext);
        }
    }
    /** 
     * function compareCiphertextData
     *
     * Compare the original ciphertext data to the new ciphertext data.
     *
     * @access private
     * @param originalCiphertext - Original ciphertext
     * @param newCiphertext - New ciphertext
     * @return true|false
     */
    private function compareCiphertextData($originalCiphertext, $newCiphertext) {
        if (FALSE != strcmp(bin2hex($originalCiphertext), bin2hex($newCiphertext))) {
            return false;
        } else {
            return true;
        }
    }
}
?>
