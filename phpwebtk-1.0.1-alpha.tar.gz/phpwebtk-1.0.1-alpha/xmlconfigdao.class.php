<?php
/**
 * $Id: xmlconfigdao.class.php,v 1.1 2004/08/13 13:04:30 bbisaillon Exp $
 * Database management, accessing and searching
 *
 * @package phpwebtk
 */
/**
 * class XMLConfigDAO
 *
 * This class defines a Data Access Object to be created by the corresponding
 * XMLDAOFactory and implements the ConfigDAO interface.
 *
 * This class contains all XML specific code and XPath statements. The
 * implementation details are hidden from the client.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.databases
 */
class XMLConfigDAO extends ConfigDAO {
    /**
     * function __construct
     *
     * This is a constructor that stores the DomDocument object in a
     * private member of this class.
     *
     * @access public
     * @param DomDocument - object of class DomDocument
     */
    public function __construct(&$DomDocument) {
        $this->DomDocument = $DomDocument;
    }
    /**
     * function __destruct
     *
     * This is a destructor that destroys the specified private members of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->DomDocument);
    }
    /**
     * function getElementsByPath
     *
     * Query an XML document for a specific node(s) matching some criteria and
     * return a collection of elements and their associated values.
     *
     * @access public
     * @param expression - XPath expression
     * @param prefix - Namespace prefix
     * @param uri - Namespace URI
     * @param noprefix - Strip namespace prefixes (optional)
     * @return array
     */
    public function &getElementsByPath($expression, $prefix, $uri, $noprefix=false) {
        $elementList = array();
        $DomXpath =& new DomXpath($this->DomDocument);
        if (!empty($prefix) && !empty($uri)) {
            $DomXpath->registerNamespace($prefix, $uri);
        }
        $DomNodeList = $DomXpath->query($expression);
        if(is_object($DomNodeList) && $DomNodeList->length) {
            foreach ($DomNodeList as $DomElement) {
                if ($noprefix) {
                    $tagName = str_replace($prefix.':', '', $DomElement->tagName);
                    $elementList[$tagName] = $DomElement->textContent;
                } else {
                    $elementList[$DomElement->tagName] = $DomElement->textContent;
                }
            }
        }
        return $elementList;
    }
    /**
     * function setElementByPath
     *
     * Query an XML document for a specific node matching some criteria and
     * replace the original text content with new text content.
     *
     * @access public
     * @param expression - XPath expression
     * @param prefix - Namespace prefix
     * @param uri - Namespace URI
     * @param textcontent = Text content
     */
    public function setElementByPath($expression, $prefix, $uri, $textcontent) {
        $DomXpath =& new DomXpath($this->DomDocument);
        if (!empty($prefix) && !empty($uri)) {
            $DomXpath->registerNamespace($prefix, $uri);
        }
        $DomNodeList = $DomXpath->query($expression);
        if(is_object($DomNodeList) && $DomNodeList->length) {
            foreach ($DomNodeList as $DomElement) {
                $DomText = $this->DomDocument->createTextNode($textcontent);
                $DomElement->replaceChild($DomText, $DomElement->firstChild);
            }
        }
        $this->DomDocument->save(PHPWEBTK_XML_CONFIG_FILE);
    }
}
?>