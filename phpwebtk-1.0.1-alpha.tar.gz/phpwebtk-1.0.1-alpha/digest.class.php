<?php
/**
 * $Id: digest.class.php,v 1.1 2004/08/13 19:48:49 bbisaillon Exp $
 * Encrypting, decrypting and hashing data
 *
 * @package phpwebtk
 */
/**
 * class Digest
 *
 * This class provides a simple interface to the mhash library. It can be used
 * to create both salted and unsalted message digests. mhash was chosen because
 * it supports a wide variety of hash algorithms. For a complete list of
 * supported hashes, refer to the documentation of mhash.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.cryptography
 */
class Digest {
    private $XMLConfigDAO;
    private $saltedS2kAlgorithm;
    private $digestAlgorithm;
    private $digestAlgorithmBlockSize;
    private $randomDevice;
    /**
     * function __construct
     *
     * This is a constructor that creates a new object of class DomDocument.
     * The DomDocument object is then passed as a parameter to the
     * XMLDAOFactory and an XMLConfigDAO object is returned. The XMLConfigDAO
     * object is then used to query XML nodes using XPath and builds an
     * elementList array. The values in the array are then stored into private
     * members of this class for further usage by other functions.
     *
     * @access public
     */
    public function __construct() {
        $DomDocument = XMLDAOFactory::loadXMLFile(PHPWEBTK_XML_CONFIG_FILE);
        $this->XMLConfigDAO = XMLDAOFactory::getXMLDao($DomDocument);
        $elementList =& $this->XMLConfigDAO->getElementsByPath('//digest:*', 'digest', 'http://sourceforge.net/projects/phpwebtk', true);
        $this->saltedS2kAlgorithm = $elementList['saltedS2kAlgorithm'];
        $this->digestAlgorithm = $elementList['digestAlgorithm'];
        $this->digestAlgorithmBlockSize = Hash::getBlockSize($this->digestAlgorithm);
        $this->randomDevice = $elementList['randomDevice'];
    }
    /**
     * function __destruct
     *
     * This is a destructor that destroys the specified private members of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->randomDevice,$this->digestAlgorithmBlockSize,$this->digestAlgorithm,$this->saltedS2kAlgorithm,$this->XMLConfigDAO);
    }
    /**
     * function getDigest
     *
     * Generate a salted or unsalted message digest.
     *
     * @access public
     * @param plaintext - Plaintext data to encode
     * @return string
     */
    public function getDigest($plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {
            $salt = mhash_keygen_s2k($this->digestAlgorithm, $plaintext, substr(pack('h*', bin2hex(mhash($this->digestAlgorithm, $this->randomDevice))), 0, 8), 4);
            return base64_encode(mhash($this->digestAlgorithm, $plaintext.$salt).$salt);
        } else {
            return base64_encode(mhash($this->digestAlgorithm, $plaintext));
        }
    }
    /**
     * function isValidDigest
     *
     * Validate a salted or unsalted message digest.
     *
     * @access public
     * @param ciphertext - Ciphertext data for comparison
     * @param plaintext - Plaintext data for comparison
     * @return true|false
     */
    public function isValidDigest($ciphertext, $plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {
            $originalCiphertext = substr(base64_decode($ciphertext), 0, $this->digestAlgorithmBlockSize);
            $salt = substr(base64_decode($ciphertext), $this->digestAlgorithmBlockSize);
            $newCiphertext = mhash($this->digestAlgorithm, $plaintext.$salt);
            return Hash::compareCiphertextData($originalCiphertext.$salt, $newCiphertext.$salt);
        } else {
            $originalCiphertext = base64_decode($ciphertext);
            $newCiphertext = mhash($this->digestAlgorithm, $plaintext);
            return Hash::compareCiphertextData($originalCiphertext, $newCiphertext);
        }
    }
}
?>