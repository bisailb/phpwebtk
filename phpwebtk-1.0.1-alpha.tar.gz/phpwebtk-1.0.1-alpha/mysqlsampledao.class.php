<?php
/**
 * $Id: mysqlsampledao.class.php,v 1.1 2004/08/13 13:04:30 bbisaillon Exp $
 * Database management, accessing and searching
 *
 * @package phpwebtk
 */
/**
 * class MySQLSampleDAO
 *
 * This class defines a Data Access Object to be created by the corresponding
 * MySQLDAOFactory and implements the SampleDAO interface.
 *
 * This class contains all MySQL specific code and SQL statements. The
 * implementation details are hidden from the client.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.databases
 */
class MySQLSampleDAO extends SampleDAO {
    // Private members
    private $dsn;
    /**
     * function __construct
     *
     * This is a constructor that stores the Data Source Name (DSN) in a
     * specified private member of this class.
     *
     * @access public
     * @param dsn - Data Source Name (DSN)
     */
    public function __construct($dsn) {
        $this->dsn = $dsn;
    }
    /**
     * function __destruct
     *
     * This is a destructor that destroys the specified private members of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->dsn);
    }
    /**
     * function insertSample
     *
     * This function gets a database connection object, executes SQL insert
     * statements and catches any exceptions thrown.
     *
     * @access public
     */
    public function insertSample() {
        try {
            $Database = MySQLDAOFactory::createConnection($this->dsn);
            $Database->Execute('INSERT INTO `sample` VALUES (1, 10.00, \'ABCDEFGHIJK\', \'1\');');
            $Database->Execute('INSERT INTO `sample` VALUES (2, 20.00, \'ABCDEFGHIJK\', \'2\');');
        } catch (Exception $Exception) {
            adodb_backtrace($Exception->gettrace());
        }
    }
    /**
     * function deleteSample
     *
     * This function gets a database connection object, executes SQL delete
     * statements and catches any exceptions thrown.
     *
     * @access public
     */
    public function deleteSample() {
        try {
            $Database = MySQLDAOFactory::createConnection($this->dsn);
            $Database->Execute('DELETE FROM `sample` WHERE `id` = \'2\' LIMIT 1');
            $Database->Execute('DELETE FROM `sample` WHERE `id` = \'1\' LIMIT 1');
        } catch (Exception $Exception) {
            adodb_backtrace($Exception->gettrace());
        }
    }
    /**
     * function findSample
     *
     * This function gets a database connection object, executes SQL select
     * select statements, parses recordsets and catches any exceptions thrown.
     *
     * @access public
     */
    public function findSample() {
        try {
            $Database = MySQLDAOFactory::createConnection($this->dsn);
            $RecordSet = $Database->Execute('SELECT `id` FROM `sample` WHERE `id` LIKE 1 ORDER BY `id` ASC');
            $this->getData($RecordSet);
            $RecordSet = $Database->Execute('SELECT `id` FROM `sample` WHERE `id` LIKE 2 ORDER BY `id` ASC');
            $this->getData($RecordSet);
        } catch (Exception $Exception) {
            adodb_backtrace($Exception->gettrace());
        }
    }
    /**
     * function updateSample
     *
     * This function gets a database connection object, executes SQL update
     * update statements and catches any exceptions thrown.
     *
     * @access public
     */
    public function updateSample() {
        try {
           $Database = MySQLDAOFactory::createConnection($this->dsn);
           $Database->Execute('UPDATE `sample` SET `price` = \'15.00\' WHERE `id` = \'1\' LIMIT 1 ;');
           $Database->Execute('UPDATE `sample` SET `price` = \'25.00\' WHERE `id` = \'2\' LIMIT 1 ;');
       } catch (Exception $Exception) {
            adodb_backtrace($Exception->gettrace());
        }
    }
    /**
     * function selectSampleRS
     *
     * This function gets a database connection object, executes SQL select
     * statements, parses recordsets and catches any exceptions thrown.
     *
     * @access public
     */
    public function selectSampleRS() {
        try {
           $Database = MySQLDAOFactory::createConnection($this->dsn);
           $RecordSet = $Database->Execute('SELECT * FROM `sample`');
           $this->getData($RecordSet);
       } catch (Exception $Exception) {
            adodb_backtrace($Exception->gettrace());
        }
    }
    /**
     * function selectSampleTO
     *
     * This function gets a database connection object, executes SQL select
     * statements, parses recordsets and catches any exceptions thrown.
     *
     * @access public
     */
    public function selectSampleTO() {
        try {
           $Database = MySQLiDAOFactory::createConnection($this->dsn);
           $RecordSet = $Database->Execute('SELECT * FROM `sample`');
           $this->getDataTO($RecordSet);
        } catch (Exception $Exception) {
            adodb_backtrace($Exception->gettrace());
        }
    }
    /**
     * function getData
     *
     * This function uses PEAR style data retrieval to get arrays containing
     * the current row. FetchRow() internally moves to the next record after
     * returning the current row.
     *
     * @access public
     */
    public function getData($RecordSet) {
        while ($sample = $RecordSet->FetchRow()) {
            print_r($sample);
        }
    }
    /**
     * function getDataTO
     *
     * This function uses PEAR style data retrieval to get the current row as
     * an object. FetchNextObject() internally moves to the next row
     * automatically.
     *
     * @access public
     */
    public function getDataTO($RecordSet) {
        while ($SampleTO = $RecordSet->FetchNextObject($toupper=false)) {
            print($SampleTO->price . '<br />');
        }
    }
}
?>