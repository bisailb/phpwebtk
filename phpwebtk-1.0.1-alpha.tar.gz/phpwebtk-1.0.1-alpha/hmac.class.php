<?php
/**
 * $Id: hmac.class.php,v 1.1 2004/08/13 19:48:49 bbisaillon Exp $
 * Encrypting, decrypting and hashing data
 *
 * @package phpwebtk
 */
/**
 * class Hmac
 *
 * This class provides a simple interface to the mhash library. It can be used
 * to create both salted and unsalted message authentication codes. mhash was
 * chosen because it supports a wide variety of hash algorithms. For a complete
 * list of supported hashes, refer to the documentation of mhash.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.cryptography
 */
class Hmac {
    private $XMLConfigDAO;
    private $saltedS2kAlgorithm;
    private $hmacAlgorithm;
    private $hmacAlgorithmBlockSize;
    private $randomDevice;
    private $secretKey;
    /**
     * function __construct
     *
     * This is a constructor that creates a new object of class DomDocument.
     * The DomDocument object is then passed as a parameter to the
     * XMLDAOFactory and an XMLConfigDAO object is returned. The XMLConfigDAO
     * object is then used to query XML nodes using XPath and builds an
     * elementList array. The values in the array are then stored into private
     * members of this class for further usage by other functions.
     *
     * @access public
     */
    public function __construct() {
        $DomDocument = XMLDAOFactory::loadXMLFile(PHPWEBTK_XML_CONFIG_FILE);
        $this->XMLConfigDAO = XMLDAOFactory::getXMLDao($DomDocument);
        $elementList =& $this->XMLConfigDAO->getElementsByPath('//hmac:*', 'hmac', 'http://sourceforge.net/projects/phpwebtk', true);
        $this->saltedS2kAlgorithm = $elementList['saltedS2kAlgorithm'];
        $this->hmacAlgorithm = $elementList['hmacAlgorithm'];
        $this->hmacAlgorithmBlockSize = Hash::getBlockSize($this->hmacAlgorithm);
        $this->randomDevice = $elementList['randomDevice'];
        $this->secretKey = $elementList['secretKey'];
    }
    /**
     * function __destruct
     *
     * This is a destructor that destroys the specified private members of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->secretKey,$this->randomDevice,$this->hmacAlgorithmBlockSize,$this->hmacAlgorithm,$this->saltedS2kAlgorithm,$this->XMLConfigDAO);
    }
    /**
     * function setSecretKey
     *
     * Create a secret key up to the length of the block size of the specified
     * hash, hash the key and then use the resultant length of the hash output
     * as the actual key to HMAC.
     *
     * @access public
     * @param plaintext - Plaintext data to use as a key
     * @return string
     */
    public function setSecretKey($plaintext) {
        $elementList =& $this->XMLConfigDAO->getElementsByPath('//prng:*', 'prng', 'http://sourceforge.net/projects/phpwebtk', true);
        $randomDevice = $elementList['randomDevice'];
        $Prng =& new Prng();
        $salt = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabchefghjkmnpqrstuvwxyz0123456789';
        for ($i = 0; $i < Hash::getBlockSize($this->hmacAlgorithm); $i++) {
            $number = $Prng->getPseudoRandomValue($randomDevice) % 59;
            $tmpPlaintext = substr($salt, $number, 1);
            $plaintext = $plaintext . $tmpPlaintext;
        }
        $this->secretKey = base64_encode(mhash_keygen_s2k($this->hmacAlgorithm, $plaintext, substr(pack('h*', bin2hex(mhash($this->hmacAlgorithm, $Prng->getPseudoRandomValue($randomDevice)))), 0, 8), Hash::getBlockSize($this->hmacAlgorithm)));
        $this->XMLConfigDAO->setElementByPath('//hmac:secretKey', 'hmac', 'http://sourceforge.net/projects/phpwebtk', $this->secretKey);
        return $this->secretKey;
    }
    /**
     * function getHmac
     *
     * Generate a salted or unsalted IETF RFC 2104 compliant message
     * authentication code (HMAC).
     *
     * @access public
     * @param plaintext - Plaintext to encode
     * @return string
     */
    public function getHmac($plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {
            $salt = mhash_keygen_s2k($this->hmacAlgorithm, $plaintext, substr(pack('h*', bin2hex(mhash($this->hmacAlgorithm, $this->randomDevice))), 0, 8), 4);
            return base64_encode(mhash($this->hmacAlgorithm, $plaintext.$salt, base64_decode($this->secretKey)).$salt);
        } else {
            return base64_encode(mhash($this->hmacAlgorithm, $plaintext, base64_decode($this->secretKey)));
        }
    }
    /**
     * function isValidHmac
     *
     * Validate a salted or unsalted IETF RFC 2104 compliant message
     * authentication code (HMAC).
     *
     * @access public
     * @param ciphertext - Ciphertext data for comparison
     * @param plaintext - Plaintext data for comparison
     * @return true|false
     */
    public function isValidHmac($ciphertext, $plaintext) {
        if (FALSE != $this->saltedS2kAlgorithm) {
            $originalCiphertext = substr(base64_decode($ciphertext), 0, $this->hmacAlgorithmBlockSize);
            $salt = substr(base64_decode($ciphertext), $this->hmacAlgorithmBlockSize);
            $newCiphertext = mhash($this->hmacAlgorithm, $plaintext.$salt, base64_decode($this->secretKey));
            return Hash::compareCiphertextData($originalCiphertext.$salt, $newCiphertext.$salt);
        } else {
            $originalCiphertext = base64_decode($ciphertext);
            $newCiphertext = mhash($this->hmacAlgorithm, $plaintext, base64_decode($this->secretKey));
            return Hash::compareCiphertextData($originalCiphertext, $newCiphertext);
        }
    }
}
?>