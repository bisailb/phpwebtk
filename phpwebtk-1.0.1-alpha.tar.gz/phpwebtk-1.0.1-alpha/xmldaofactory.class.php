<?php
/**
 * $Id: xmldaofactory.class.php,v 1.1 2004/08/13 13:04:30 bbisaillon Exp $
 * Database management, accessing and searching
 *
 * @package phpwebtk
 */
/**
 * class XMLDAOFactory
 *
 * This class implements the DAOFactory's operations that create concrete
 * XML Data Access Objects (DAOs).
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.databases
 */
class XMLDAOFactory extends DAOFactory {
    /**
     * function __construct
     *
     * This is a constructor that does nothing.
     *
     * @access public
     */
    public function __construct() {
    }
    /**
     * function __destruct
     *
     * This is a destructor that does nothing.
     *
     * @access public
     */
    public function __destruct() {
    }
    /**
     * function loadXMLFile
     *
     * This function loads XML from a file.
     *
     * @access public
     * @param dsn - Data Source Name (DSN)
     * @static
     * @return object
     */
    public static function loadXMLFile($filename) {
        if (file_exists($filename)) {
            $DomDocument =& new DomDocument();
            if (!$DomDocument->load($filename)) {
                exit('Fatal: Error while parsing ' . $filename);
            } else {
                $DomDocument->preserveWhiteSpace = false;
                return $DomDocument;
            }
        } else {
            exit('Fatal: Failed to open ' . $filename);
        }
    }
    /**
     * function getXMLDAO
     *
     * This function creates a new object of class XMLConfigDAO.
     *
     * @access public
     * @param DomDocument - object of class DomDocument
     * @return object
     */
    public function getXMLDAO(&$DomDocument) {
        return new XMLConfigDAO($DomDocument);
    }
}
?>