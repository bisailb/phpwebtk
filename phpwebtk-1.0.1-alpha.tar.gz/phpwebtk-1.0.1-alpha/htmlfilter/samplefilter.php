<?php
function getmicrotime(){
    list($usec, $sec) = explode(' ', microtime());
    return ((float)$usec + (float)$sec);
}

/**
 * Explorer will ignore this. Keep in mind.
 */
header('Content-type: text/plain');

if (isset($_SERVER{'QUERY_STRING'}) && $_SERVER{'QUERY_STRING'} == 'show'){
    readfile('samplefilter.php');
    exit;
}

require('htmlfilter.inc');

$body = '';

if (isset($_POST{'rawhtml'}) && strlen($_POST{'rawhtml'}) > 1){
    echo "Using html from the form.\n";
    $body = stripslashes($_POST{'rawhtml'});
} else if (isset($_POST{'urladdy'}) && strlen($_POST{'urladdy'}) > 1){
    if (preg_match('|^http://|', $_POST{'urladdy'})){
        echo 'Loading HTML from the web...';
        $time_start = getmicrotime();
        $body = join('', file($_POST{'urladdy'}));
        echo 'done in ';
        $mstime = number_format(getmicrotime() - $time_start, 3, '.', 3);
        echo "$mstime seconds\n";
    } else {
        echo 'Your sister wears cowboy boots.';
        exit;
    }
}

if (!strlen($body)){
    echo "I need some content!\n";
    exit;
} else {
    echo 'Got ' . strlen($body) . " chars of content.\n";
}

if (isset($_POST{'debug'}) && $_POST{'debug'} == 'on'){
    $debug = true;
} else {
    $debug = false;
}

$tag_list = Array(
                  false,
                  'blink',
                  'object',
                  'meta',
                  'font',
                  'html',
                  'link',
                  'frame',
                  'iframe',
                  'layer',
                  'ilayer',
                  'plaintext'
                 );

/**
 * A very exclusive set:
 */
// $tag_list = Array(true, "b", "a", "i", "img", "strong", "em", "p");

$rm_tags_with_content = Array(
                              'script',
                              'style',
                              'applet',
                              'embed',
                              'head',
                              'frameset',
                              'xml'
                              );

$self_closing_tags =  Array(
                            'img',
                            'br',
                            'hr',
                            'input'
                            );

$force_tag_closing = true;

$rm_attnames = Array(
    '/.*/' =>
        Array(
              '/target/i',
              '/^on.*/i',
              '/^dynsrc/i',
              '/^datasrc/i',
              '/^data.*/i',
              '/^lowsrc/i'
              )
    );

/**
 * Yeah-yeah, so this looks horrible. Check out htmlfilter.inc for
 * some idea of what's going on here. :)
 */

$bad_attvals = Array(
    '/.*/' =>
    Array(
          '/.*/' =>
	          Array(
	                Array(
                          '/^([\'\"])\s*\S+\s*script\s*:*(.*)([\'\"])/si',
                          '/^([\'\"])\s*https*\s*:(.*)([\'\"])/si',
                          '/^([\'\"])\s*mocha\s*:*(.*)([\'\"])/si',
                          '/^([\'\"])\s*about\s*:(.*)([\'\"])/si'
                          ),
                    Array(
                          '\\1oddjob:\\2\\1',
                          '\\1uucp:\\2\\1',
                          '\\1amaretto:\\2\\1',
                          '\\1round:\\2\\1'
                          )
                    ),     
          
          '/^style/i' =>
                  Array(
                        Array(
                              '/expression/i',
                              '/behaviou*r/i',
                              '/binding/i',
                              '/include-source/i',
                              '/url\s*\(\s*([\'\"]*)\s*https*:.*([\'\"]*)\s*\)/si',
                              '/url\s*\(\s*([\'\"]*)\s*\S+\s*script:.*([\'\"]*)\s*\)/si'
                             ),
                        Array(
                              'idiocy',
                              'idiocy',
                              'idiocy',
                              'idiocy',
                              'url(\\1http://securityfocus.com/\\1)',
                              'url(\\1http://securityfocus.com/\\1)'
                             )
                        )
              )
    );

$add_attr_to_tag = Array(
                         '/^a$/i' => Array('target' => '"_new"')
                         );
                         
spew("\n\n\n--------- Begin processing ----------\n");
$time_start = getmicrotime();
$trusted = sanitize($body, 
                    $tag_list, 
                    $rm_tags_with_content,
                    $self_closing_tags,
                    $force_tag_closing,
                    $rm_attnames,
                    $bad_attvals,
                    $add_attr_to_tag
                    );
spew("----------- Finished processing -----------\n");
echo 'HTML filtering time: ';
$mstime = number_format(getmicrotime() - $time_start, 3, '.', 3);
echo "$mstime seconds\n";
echo '
-------------
Final output:
-------------

';
echo $trusted;

?>
