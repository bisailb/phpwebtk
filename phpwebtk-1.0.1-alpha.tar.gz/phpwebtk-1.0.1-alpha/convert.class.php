<?php
/**
 * $Id: convert.class.php,v 1.1 2004/08/13 13:12:15 bbisaillon Exp $
 * Unit and datatype conversion
 *
 * @package phpwebtk
 */
/**
 * class Convert
 *
 * This class provides simple data conversion functions.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.conversion
 */
class Convert {
    /**
     * function __construct
     *
     * This is a constructor that does nothing.
     *
     * @access public
     */
    public function __construct() {
    }
    /**
     * function __destruct
     *
     * This is a destructor that does nothing.
     *
     * @access public
     */
    public function __destruct() {
    }
    /**
     * function hex2bin
     *
     * Convert hexadecimal data into a binary string.
     *
     * @access public
     * @param hexData - Hexadecimal data to convert
     * @return string
     * @static
     */
    public static function hex2bin($hexData) {
        $length = strlen($hexData);
        return pack('H' . $length, $hexData);
    }
}
?>