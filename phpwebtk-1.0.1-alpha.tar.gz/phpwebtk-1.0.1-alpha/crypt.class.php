<?php
/**
 * $Id: crypt.class.php,v 1.5 2004/08/13 19:46:06 bbisaillon Exp $
 * Encrypting, decrypting and hashing data
 *
 * @package phpwebtk
 */
/**
 * class Crypt
 *
 * This class provides a simple interface to the mcrypt library. It can be
 * used to encrypt and decrypt data. mcrypt was chosen because it supports a
 * wide variety of block algorithms and cipher modes. For a complete list of
 * supported algorithms and modes refer to the documentation of mcrypt.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.cryptography
 */
class Crypt extends Exception {
    private $XMLConfigDAO;
    private $encryptionDescriptor;
    private $initializationVector;
    private $randomDevice;
    private $blockAlgorithm;
    private $blockAlgorithmMode;
    private $cipherKey;
    /**
     * function __construct
     *
     * This is a constructor that creates a new object of class DomDocument.
     * The DomDocument object is then passed as a parameter to the
     * XMLDAOFactory and an XMLConfigDAO object is returned. The XMLConfigDAO
     * object is then used to query XML nodes using XPath and builds an
     * elementList array. The values in the array are then stored into private
     * members of this class for further usage by other functions.
     *
     * @access public
     */
    public function __construct() {
        $DomDocument = XMLDAOFactory::loadXMLFile(PHPWEBTK_XML_CONFIG_FILE);
        $this->XMLConfigDAO = XMLDAOFactory::getXMLDao($DomDocument);
        $elementList =& $this->XMLConfigDAO->getElementsByPath('//crypt:*', 'crypt', 'http://sourceforge.net/projects/phpwebtk', true);
        $this->randomDevice = $elementList['randomDevice'];
        $this->blockAlgorithm = $elementList['blockAlgorithm'];
        $this->blockAlgorithmMode = $elementList['blockAlgorithmMode'];
        $this->cipherKey = $elementList['cipherKey'];
    }
    /**
     * function __destruct
     *
     * This is a destructor that destroys the specified private members of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->cipherKey,$this->blockAlgorithmMode,$this->blockAlgorithm,$this->randomDevice,$this->XMLConfigDAO);
    }
    /**
     * function getIvSize
     *
     * Get the size of the Initialization Vector (IV) of the opened algorithm.
     *
     * @access private
     * @return integer
     */
    private function getIvSize() {
        return mcrypt_enc_get_iv_size($this->encryptionDescriptor);
    }
    /**
     * function getKeySize
     *
     * Get the maximum supported key size of the opened mode.
     *
     * @access private
     * @return integer
     */
    private function getKeySize() {
        return mcrypt_enc_get_key_size($this->encryptionDescriptor);
    }
    /**
     * function getBlockSize
     *
     * Get the block size of the opened algorithm.
     *
     * @access private
     * @return integer
     */
    private function getBlockSize() {
        return mcrypt_enc_get_block_size($this->encryptionDescriptor);
    }
    /**
     * function openModule
     *
     * Opens the module of the algorithm and the mode to be used.
     *
     * @access private
     * @return integer|false
     */
    private function openModule() {
        try {
            if (FALSE != ($this->encryptionDescriptor = mcrypt_module_open($this->blockAlgorithm, '', $this->blockAlgorithmMode, ''))) {
            } else {
                throw new Exception('<br /><h1>Encryption Module Failure</h1><strong>Fatal:</strong> openModule(): Failed to open encryption module: phpwebtk.cryptography.Crypt.Exception at <strong>');
            }
        } catch (Exception $Exception) {
            exit($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . '</strong> on line <strong>' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
        }
    }
    /**
     * function getRandomIv
     *
     * Get initialization vector (IV) from the registered session.
     *
     * @access private
     * @return string
     */
    private function getRandomIv() {
        if (isset($_SESSION['randomIv']) && !empty($_SESSION['randomIv'])) {
            try {
                if (FALSE != ($this->initializationVector = base64_decode($_SESSION['randomIv']))) {
                    return $this->initializationVector;
                } else {
                    throw new Exception('<br /><h1>Decoding Failed</h1><strong>Fatal:</strong> base64_decode(): Failed to decode data: phpwebtk.cryptography.Crypt.Exception at <strong>');
                }
            } catch (Exception $Exception) {
                exit($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . '</strong> on line <strong>' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
            }
        }
    }
    /**
     * function setRandomIv
     *
     * Create an initialization vector (IV) from a random source and store it
     * in a registered session.
     *
     * @access private
     * @return string
     */
    private function setRandomIv() {
        if (isset($_SESSION['randomIv']) && !empty($_SESSION['randomIv'])) {
            try {
                if (FALSE != ($this->initializationVector = base64_decode($_SESSION['randomIv']))) {
                    return $this->initializationVector;
                } else {
                    throw new Exception('<br /><h1>Decoding Failed</h1><strong>Fatal:</strong> base64_decode(): Failed to decode data: phpwebtk.cryptography.Crypt.Exception at <strong>');
                }
            } catch (Exception $Exception) {
                exit($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . '</strong> on line <strong>' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
            }
        } else {
            try {
                if (FALSE != ($this->initializationVector = mcrypt_create_iv($this->getIvSize(), $this->randomDevice))) {
                    $_SESSION['randomIv'] = base64_encode($this->initializationVector);
                    return $this->initializationVector;
                } else {
                    throw new Exception('<br /><h1>IV Creation Failed</h1><strong>Fatal:</strong> mcrypt_create_iv(): Failed to create initialization vector (IV): phpwebtk.cryptography.Crypt.Exception at <strong>');
                }
            } catch (Exception $Exception) {
                exit($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . '</strong> on line <strong>' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
            }
        }
    }
    /**
     * function setCipherKey
     *
     * Create cipher key according to the maximum supported key size of the
     * opened mode.
     *
     * @access public
     * @param plaintext - Plaintext password to use as a key
     */
    public function setCipherKey($plaintext) {
        $elementList =& $this->XMLConfigDAO->getElementsByPath('//prng:*', 'prng', 'http://sourceforge.net/projects/phpwebtk', true);
        $randomDevice = $elementList['randomDevice'];
        $Prng =& new Prng();
        $Hmac =& new Hmac(PHPWEBTK_XML_CONFIG_FILE);
        $this->openModule();
        $salt = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabchefghjkmnpqrstuvwxyz0123456789';
        for ($i = 0; $i < $this->getKeySize(); $i++) {
            $number = $Prng->getPseudoRandomValue($randomDevice) % 59;
            $tmpPlaintext = substr($salt, $number, 1);
            $plaintext = $plaintext . $tmpPlaintext;
        }
        $this->cipherKey = $Hmac->getHmac($plaintext);
        $this->XMLConfigDAO->setElementByPath('//crypt:cipherKey', 'crypt', 'http://sourceforge.net/projects/phpwebtk', $this->cipherKey);
        $this->closeModule();
        return $this->cipherKey;
    }
    /**
     * function encrypt
     *
     * Initialize all buffers needed for encryption, encrypt data and
     * deinitialize an encryption module.
     *
     * @access public
     * @param plaintext - Plaintext data to encrypt
     * @return string
     */
    public function encrypt($plaintext) {
        $this->openModule();
        $cipherKey = substr(base64_decode($this->cipherKey), 0, $this->getKeySize());
        mcrypt_generic_init($this->encryptionDescriptor, $cipherKey, $this->setRandomIv());
        $ciphertext = mcrypt_generic($this->encryptionDescriptor, $plaintext);
        mcrypt_generic_deinit($this->encryptionDescriptor);
        $this->closeModule();
        return bin2hex($ciphertext);
    }
    /**
     * function decrypt
     *
     * Initialize all buffers needed for decryption, decrypt data and
     * deinitialize a decryption module.
     *
     * @access public
     * @param ciphertext - Ciphertext data to decrypt
     * @return string
     */
    public function decrypt($ciphertext) {
        $this->openModule();
        $cipherKey = substr(base64_decode($this->cipherKey), 0, $this->getKeySize());
        mcrypt_generic_init($this->encryptionDescriptor, $cipherKey, $this->getRandomIv());
        $plaintext = mdecrypt_generic($this->encryptionDescriptor, substr(Convert::hex2bin($ciphertext), 0, $this->getIvSize()));
        mcrypt_generic_deinit($this->encryptionDescriptor);
        $this->closeModule();
        return trim($plaintext);
    }
    /**
     * function closeModule
     *
     * Close the mcrypt module.
     *
     * @access public
     */
    private function closeModule() {
        mcrypt_module_close($this->encryptionDescriptor);
    }
}
?>