<?php
/**
 * $Id: daofactory.class.php,v 1.1 2004/08/13 13:04:30 bbisaillon Exp $
 * Database management, accessing and searching
 *
 * @package phpwebtk
 */
/**
 * class DAOFactory
 *
 * This class declares an interface for operations that create abstract Data
 * Data Access Objects (DAOs).
 *
 * @abstract
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.databases
 */
abstract class DAOFactory {
    // Abstract methods
    public abstract function getSampleDAO();
    /**
     * function __construct
     *
     * This is a constructor that does nothing.
     *
     * @access public
     */
    public function __construct() {
    }
    /**
     * function __destruct
     *
     * This is a destructor that does nothing.
     *
     * @access public
     */
    public function __destruct() {
    }
    /**
     * function getDAOFactory
     *
     * This is a constructor that creates a new object of class DomDocument.
     * The DomDocument object is then passed as a parameter to the
     * XMLDAOFactory and an XMLConfigDAO object is returned. The XMLConfigDAO
     * object is then used to query XML nodes using XPath and builds an
     * elementList array. The values in the array are then stored into a Data
     * Source Name (DSN) for further usage by concrete factories.
     *
     * @access public
     */
    public static function getDAOFactory() {
        $DomDocument = XMLDAOFactory::loadXMLFile(PHPWEBTK_XML_CONFIG_FILE);
        $XMLConfigDAO = XMLDAOFactory::getXMLDao($DomDocument);
        $elementList =& $XMLConfigDAO->getElementsByPath('//mysqldao:*', 'mysqldao', 'http://sourceforge.net/projects/phpwebtk', true);
        $driver = $elementList['driver'];
        $username = $elementList['username'];
        $password = $elementList['password'];
        $hostname = $elementList['hostname'];
        $database = $elementList['database'];
        $persistent = $elementList['persistent'];
        $debug = $elementList['debug'];
        $fetchmode = $elementList['fetchmode'];
        $clientflags = $elementList['clientflags'];
        $dsn = "$driver://$username:$password@$hostname/$database?persistent=$persistent&debug=$debug&fetchmode=$fetchmode&clientflags=$clientflags";
        switch($driver) {
            case 'mysql':
                return new MySQLDAOFactory($dsn);
                break;
           case 'mysqli':
                return new MySQLiDAOFactory($dsn);
                break;
           case 'mysqlt':
                return new MySQLtDAOFactory($dsn);
                break;
            default:
                return null;
                break;
        }
    }
}
?>