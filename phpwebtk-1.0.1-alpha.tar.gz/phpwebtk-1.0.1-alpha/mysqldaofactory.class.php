<?php
/**
 * $Id: mysqldaofactory.class.php,v 1.1 2004/08/13 13:04:30 bbisaillon Exp $
 * Database management, accessing and searching
 *
 * @package phpwebtk
 */
/**
 * class MySQLDAOFactory
 *
 * This class implements the DAOFactory's operations that create concrete MySQL
 * Data Access Objects (DAOs).
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.databases
 */
class MySQLDAOFactory extends DAOFactory {
    // Private members
    private $dsn;
    // Protected members
    protected $Database;
    /**
     * function __construct
     *
     * This is a constructor that stores the Data Source Name (DSN) in a
     * specified private member of this class.
     *
     * @access public
     * @param dsn - Data Source Name (DSN)
     */
    public function __construct($dsn) {
        $this->dsn = $dsn;
    }
    /**
     * function __destruct
     *
     * This is a destructor that destroys the specified private members of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->dsn);
    }
    /**
     * function createConnection
     *
     * This function creates a database connection object using the provided
     * Data Source Name (DSN) with support for performance monitoring.
     *
     * @access public
     * @param dsn - Data Source Name (DSN)
     * @return object
     * @static
     */
    public static function createConnection($dsn) {
        $Database = NewADOConnection($dsn);
        $PerfMonitor =& NewPerfMonitor($Database);
//      $PerfMonitor->UI($pollsecs=5);
        return $Database;
    }
    /**
     * function getSampleDAO
     *
     * This function creates a new object of class MySQLSampleDAO.
     *
     * @access public
     * @return object
     */
    public function getSampleDAO() {
        return new MySQLSampleDAO($this->dsn);
    }
}
?>