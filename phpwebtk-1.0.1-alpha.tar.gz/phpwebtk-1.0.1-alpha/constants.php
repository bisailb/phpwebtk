<?php
define('ADODB_PERF_NO_RUN_SQL', 1);
define('PHPWEBTK_XML_CONFIG_FILE', '/opt/apache/share/htdocs/phpwebtk-dev/config.xml');
?>
