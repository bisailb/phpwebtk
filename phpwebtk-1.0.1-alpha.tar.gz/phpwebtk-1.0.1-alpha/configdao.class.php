<?php
/**
 * $Id: configdao.class.php,v 1.1 2004/08/13 13:04:30 bbisaillon Exp $
 * Database management, accessing and searching
 *
 * @package phpwebtk
 */
/**
 * class ConfigDAO
 *
 * Declares an interface for a type of Data Access Object (DAO).
 *
 * @abstract
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.databases
 */
abstract class ConfigDAO {
    // Abstract methods
    public abstract function &getElementsByPath($expression, $prefix, $uri, $noprefix=false);
    public abstract function setElementByPath($expression, $prefix, $uri, $textcontent);
    /**
     * function __construct
     *
     * This is a constructor that does nothing.
     *
     * @access public
     */
    public function __construct() {
    }
    /**
     * function __destruct
     *
     * This is a destructor that does nothing.
     *
     * @access public
     */
    public function __destruct() {
    }
}
?>