<?php
$start = microtime(1);
function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
    require_once('../constants.php');
}
ob_start();
$key = 'This is a sample key.';
$Crypt =& new Crypt();
$Crypt->setCipherKey($key);
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('Time Elapsed: ' , $time);
?>