<?php
$start = microtime(1);
function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
    require_once('../adodb/adodb.inc.php');
    require_once('../adodb/adodb-exceptions.inc.php');
    require_once('../constants.php');
}
ob_start();
$DAOFactory = DAOFactory::getDAOFactory();
$SampleDAO = $DAOFactory->getSampleDAO();
$SampleDAO->insertSample();
$SampleDAO->selectSampleRS();
$SampleDAO->updateSample();
$SampleDAO->selectSampleRS();
$SampleDAO->deleteSample();
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('<br />Time Elapsed: ' . $time);
?>