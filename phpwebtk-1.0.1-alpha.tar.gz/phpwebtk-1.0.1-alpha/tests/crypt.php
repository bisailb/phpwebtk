<?php
$start = microtime(1);
function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
    require_once('../constants.php');
}
ob_start();
$plaintext = 'what do ya want for nothing?';
$Crypt =& new Crypt();
$ciphertext = $Crypt->encrypt($plaintext);
print('AES-256 Ciphertext: ' . $ciphertext);
$output = $Crypt->decrypt($ciphertext);
print('<br />Plaintext: ' . $output);
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('<br />Time Elapsed: ' . $time);
?>