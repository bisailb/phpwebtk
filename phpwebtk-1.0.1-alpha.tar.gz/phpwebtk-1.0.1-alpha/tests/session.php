<?php
$start = microtime(1);
function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
    require_once('../constants.php');
}
ob_start();
$Session = new Session();
$Session->startSession();
print('Congratulations! Your new session has started.');
$Session->endSession();
print('<br />Goodbye! Your session has ended.');
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('<br />Time Elapsed: ' . $time);
?>