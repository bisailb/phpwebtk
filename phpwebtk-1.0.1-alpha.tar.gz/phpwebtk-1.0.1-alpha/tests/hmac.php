<?php
$start = microtime(1);
function __autoload($class) {
    require_once('../' . strtolower($class) . '.class.php');
    require_once('../constants.php');
}
ob_start();
$plaintext = 'what do ya want for nothing?';
$Hmac =& new Hmac();
$ciphertext = $Hmac->getHmac($plaintext);
print('SHA-256 HMAC: ' . $ciphertext);
print('<br />Plaintext: ' . $plaintext);
if (!$Hmac->isValidHmac($ciphertext, $plaintext)) {
    print('<br />Invalid Signature');
} else {
    print('<br />Signature Valid');
}
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('<br />Time Elapsed: ' . $time);
?>