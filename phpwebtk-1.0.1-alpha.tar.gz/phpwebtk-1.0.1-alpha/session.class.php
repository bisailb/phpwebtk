<?php
/**
 * $Id: session.class.php,v 1.4 2004/08/13 19:46:44 bbisaillon Exp $
 * User records, authentication and session handling
 *
 * @package phpwebtk
 */
/**
 * class Session
 *
 * Session management in PHP enables data to be preserved across subsequent
 * requests. Additional measures must be taken to actively protect the
 * integrity of the session.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.usermgmt
 */
class Session {
    private $savePath;
    private $name;
    private $cookieLifetime;
    private $cookiePath;
    private $cookieDomain;
    private $cookieSecure;
    private $cacheLimiter;
    private $cacheExpire;
    /**
     * function __construct
     *
     * This is a constructor that creates a new object of class XmlReader
     * with the XML file to load as its only parameter. Furthermore, XPath is
     * used to query XML nodes and store values from a configuration file into
     * private members of this class for further usage by other functions.
     *
     * @access public
     * @param filename - XML file to open
     */
    public function __construct() {
        $DomDocument = XMLDAOFactory::loadXMLFile(PHPWEBTK_XML_CONFIG_FILE);
        $XMLConfigDAO = XMLDAOFactory::getXMLDao($DomDocument);
        $elementList =& $XMLConfigDAO->getElementsByPath('//session:*', 'session', 'http://sourceforge.net/projects/phpwebtk', true);
        $this->savePath = $elementList['savePath'];
        $this->name = $elementList['name'];
        ini_set('session.entropy_file', $elementList['entropyFile']);
        ini_set('session.entropy_length', $elementList['entropyLength']);
        ini_set('session.use_only_cookies', $elementList['useOnlyCookies']);
        $this->cookieLifetime = $elementList['cookieLifetime'];
        $this->cookiePath = $elementList['cookiePath'];
        $this->cookieDomain = $elementList['cookieDomain'];
        $this->cookieSecure = $elementList['cookieSecure'];
        $this->cacheLimiter = $elementList['cacheLimiter'];
        $this->cacheExpire = $elementList['cacheExpire'];
        ini_set('session.hash_function', $elementList['hashFunction']);
        ini_set('session.hash_bits_per_character', $elementList['hashBitsPerCharacter']);
    }
    /**
     * function __destruct
     *
     * This is a destructor that destroys the private member variables of this
     * class.
     *
     * @access public
     */
    public function __destruct() {
        unset($this->cacheExpire,$this->cacheLimiter,$this->cookieSecure,$this->cookieDomain,$this->cookiePath,$this->cookieLifetime,$this->name,$this->savePath);
    }
    /**
     * function getCacheExpire
     *
     * Get the current cache expire setting.
     *
     * @access public
     */
    public function getCacheExpire() {
        return session_cache_expire();
    }
    /**
     * function getCacheLimiter
     *
     * Get the current cache expire setting.
     *
     * @access public
     */
    public function getCacheLimiter() {
        return session_cache_limiter();
    }
    /**
     * function getCookieParameters
     *
     * Get the session cookie parameters.
     *
     * @access public
     */
    public function getCookieParameters() {
        return session_get_cookie_params();
    }
    /**
     * function getId
     *
     * Get the current session id.
     *
     * @access public
     */
    public function getId() {
        return session_id();
    }
    /**
     * function getName
     *
     * Get the current session name.
     *
     * @access public
     */
    public function getName() {
        return session_name();
    }
    /**
     * function getSavePath
     *
     * Get the current session save path.
     *
     * @access public
     */
    public function getSavePath() {
        return session_save_path();
    }
    /**
     * function startSession
     *
     * Set the current session save path, the session name, the session cookie
     * parameters, the current cache limiter, the current cache expire and
     * initialize the session.
     *
     * @access public
     */
    public function startSession() {
        session_save_path($this->savePath);
        session_name($this->name);
        session_set_cookie_params($this->cookieLifetime, $this->cookiePath, $this->cookieDomain, $this->cookieSecure);
        session_cache_limiter($this->cacheLimiter);
        session_cache_expire($this->cacheExpire);
        if (!session_id()) {
            session_start();
        }
    }
    /**
     * function endSession() {
     *
     * Initialize the session, destroy all data registered to a session, and
     * expire the session cookie.
     *
     * @access public
     */
    public function endSession() {
        $this->startSession();
        $_SESSION = array();
        session_destroy();
        $cookie_params = session_get_cookie_params();
        if (empty($cookie_params['domain']) && empty($cookie_params['secure'])) {
            setcookie(session_name(), session_id(), time()-3600, $cookie_params['path']);
        }
        elseif (empty($cookie_params['secure'])) {
            setcookie(session_name(), session_id(), time()-3600, $cookie_params['path'], $cookie_params['domain']);
        } else {
            setcookie(session_name(), session_id(), time()-3600, $cookie_params['path'], $cookie_params['domain'], $cookie_params['secure']);
        }
    }
}
?>