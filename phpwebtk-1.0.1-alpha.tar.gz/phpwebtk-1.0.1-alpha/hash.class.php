<?php
/**
 * $Id: hash.class.php,v 1.5 2004/08/13 19:46:06 bbisaillon Exp $
 * Encrypting, decrypting and hashing data
 *
 * @package phpwebtk
 */
/**
 * class Hash
 *
 * This class provides a simple interface to the mhash library. mhash was
 * chosen because it supports a wide variety of hash algorithms. For a complete
 * list of supported hashes, refer to the documentation of mhash.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk.cryptography
 */
class Hash extends Exception {
    /**
     * function __construct
     *
     * This is a constructor that does nothing.
     *
     * @access public
     */
    public function __construct() {
    }
    /**
     * function __destruct
     *
     * This is a destructor that does nothing.
     *
     * @access public
     */
    public function __destruct() {
    }
    /**
     * function getHashInfo
     *
     * Display the hash id, the algorithm and the block size for each hash
     * algorithm supported by the mhash library.
     *
     * @access public
     * @return string
     * @static
     */
    public static function getHashInfo() {
        $hashId = mhash_count();
        print("\n");
        for ($i = 0; $i < $hashId; $i++) {
            if (FALSE != mhash_get_block_size($i)) {
                print('Hash ID: ' . $i . "\n" . 'Algorithm: ' . mhash_get_hash_name($i) . "\n" . 'Output Size: ' . mhash_get_block_size($i) . "\n\n");
            }
        }
    }
    /**
     * function getBlockSize
     *
     * Get the block size of the specified hash.
     *
     * @access public
     * @param hashId - Hash identifier
     * @return integer|false
     * @static
     */
    public static function getBlockSize($hashId) {
        try {
            if (FALSE != mhash_get_block_size($hashId)) {
                return mhash_get_block_size($hashId);
            } else {
                throw new Exception('<br /><h1>Hash ID Not Found</h1><strong>Fatal:</strong> mhash_get_block_size(): The specified hash id ' . $hashId . ' does not exist: phpwebtk.cryptography.Crypt.Exception at <strong>');
            }
        }
        catch (Exception $Exception) {
            exit($Exception->getMessage() . $_SERVER['SCRIPT_NAME'] . '</strong> on line <strong>' . $Exception->getLine() . '</strong>.<hr />' . $_SERVER['SERVER_SIGNATURE'] . '<br />');
        }
    }
    /**
     * function compareCiphertextData
     *
     * Compare the original ciphertext data to the new ciphertext data.
     *
     * @access public
     * @param originalCiphertext - Original ciphertext data for comparison
     * @param newCiphertext - New ciphertext data for comparison
     * @return true|false
     * @static
     */
    public static function compareCiphertextData($originalCiphertext, $newCiphertext) {
        if (FALSE != strcmp(bin2hex($originalCiphertext), bin2hex($newCiphertext))) {
            return false;
        } else {
            return true;
        }
    }
}
?>