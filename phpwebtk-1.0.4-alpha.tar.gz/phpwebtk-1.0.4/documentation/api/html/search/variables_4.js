var searchData=
[
  ['schema_5ffile',['SCHEMA_FILE',['../constants_8php.html#a9ceb7dbdbc9f2dfff168680bdb2107ab',1,'constants.php']]],
  ['smarty_5fdir',['SMARTY_DIR',['../constants_8php.html#a2f722c2551d08c1aad9b6f47ba9ae848',1,'constants.php']]]
];
