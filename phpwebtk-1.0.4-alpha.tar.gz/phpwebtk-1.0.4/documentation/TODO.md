Pending:

* Support for new databases such as MariaDB, PostgreSQL 9, etc.
* DAO factories need to be reworked to support the latest databases
* Rework sample schemas and test scripts for different databases
* Full-fledged demo web application using the framework and addons
* Reduce the number of sample templates to two for use in the demo

Ongoing:

* phpwebtk-1.0.4 and higher is now being updated using PHP 7.0.x
