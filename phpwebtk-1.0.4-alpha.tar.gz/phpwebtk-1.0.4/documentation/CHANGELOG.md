12 Nov 2016

* General:
   * Formatted all the code using Zend Eclipse PDT

* Documentation:
   * phpDocumentor for PHP 5 will no longer be used
   * doxygen is now being used to create new API docs

* SampleView:
   * Used new method of turning off smarty cache
   * Removed obselete code left over from Smarty2
   * Added support for Smarty3 security policy
   * Moved all CSS into their own sub-directories

* View:
   * Removed extraneous slash in URI for HTTP header

* XmlDaoFactory:
   * Using new function name and init for DOMDocument
