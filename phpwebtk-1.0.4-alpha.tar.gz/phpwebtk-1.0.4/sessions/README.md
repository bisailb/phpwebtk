* You should move this "sessions" directory outside of your web
  server's document root as described in the INSTALL documentation.