<?php
/**
 * $Id: sampleview.class.php,v 1.1 2004/11/23 14:28:26 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.3 Alpha
 *
 * @package phpwebtk
 */
/**
 * class SampleView
 *
 * This class represents and displays information to the end user. The
 * information that is used in a dynamic display is retrieved from a
 * model. Handlers support views by encapsulating and adapting a model
 * for use in a display.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage templates
 */
class SampleView {
    // Private members
    private $Request;
    private $Smarty;
    /**
     * function __construct
     *
     * This method is executed when an object is instantiated from this
     * class. Preprocessing can be done here before the object is put
     * into service.
     *
     * @access public
     */
    public function __construct(Request $Request) {
        $this->Request = $Request;
        $this->Smarty = new Smarty();
    }
    /**
     * function SetSmartyCaching
     *
     * This method is sets Smarty's caching options.
     *
     * @access public
     */
    private function SetSmartyCaching() {
        $this->Smarty->cache_dir = CLASS_PATH.'sampleview/cache';
        //$this->Smarty->cache_handler_func = array($this, 'function');
        $this->Smarty->cache_lifetime = 1800;
        $this->Smarty->cache_modified_check = false;
        $this->Smarty->caching = false;
    }
    /**
     * function SetSmartyCompiler
     *
     * This method sets Smarty's compiler options.
     *
     * @access public
     */
    private function SetSmartyCompiler() {
        $this->Smarty->compile_check = true;
        $this->Smarty->compile_dir = CLASS_PATH.'sampleview/templates_c';
        $this->Smarty->compile_id = 'en';
        $this->Smarty->compiler_class = 'Smarty_Compiler';
        $this->Smarty->force_compile = true;
    }
    /**
     * function SetSmartyConfiguration
     *
     * This method sets Smarty's configuration options.
     *
     * @access public
     */
    private function SetSmartyConfiguration() {
        $this->Smarty->config_booleanize = true;
        $this->Smarty->config_dir = CLASS_PATH.'sampleview/configs';
        $this->Smarty->config_fix_newlines = true;
        $this->Smarty->config_overwrite = false;
        $this->Smarty->config_read_hidden = false;
    }
    /**
     * function SetSmartyDebugging
     *
     * This method sets Smarty's debugging options.
     *
     * @access public
     */
    private function SetSmartyDebugging() {
        $this->Smarty->debug_tpl = SMARTY_DIR.'debug.tpl';
        $this->Smarty->debugging = false;
        $this->Smarty->debugging_ctrl = 'URL';
    }
    /**
     * function SetSmartyDebugging
     *
     * This method sets Smarty's filtering options.
     *
     * @access public
     */
    private function SetSmartyFilters() {
        //$this->Smarty->autoload_filters = array('pre' => array('trim', 'stamp'), 'output' => array('convert'));
        $this->Smarty->load_filter('output', 'tidyrepairhtml');
    }
    /**
     * function SetSmartySecurity
     *
     * This method sets Smarty's security options.
     *
     * @access public
     */
    private function SetSmartySecurity() {
        //$this->Smarty->secure_dir = array('directory1', 'directory2');
        $this->Smarty->security = false;
        $this->Smarty->security_settings = array('PHP_HANDLING' => false, 'IF_FUNCS' => array('array', 'list', 'isset', 'empty', 'count', 'sizeof', 'in_array', 'is_array', 'true','false'), 'INCLUDE_ANY' => false, 'PHP_TAGS' => false, 'MODIFIER_FUNCS' => array('count'), 'ALLOW_CONSTANTS' => false);
        $this->Smarty->trusted_dir = array();
    }
    /**
     * function SetSmartyMiscellaneous
     *
     * This method sets Smarty's other miscellaneous options.
     *
     * @access public
     */
    private function SetSmartyMiscellaneous() {
        //$this->Smarty->default_modifiers = array('escape:htmlall');
        $this->Smarty->default_resource_type = 'file';
        //$this->Smarty->default_template_handler_func = array($this, 'function');
        //$this->Smarty->error_reporting = 'value';
        $this->Smarty->left_delimiter = '{';
        $this->Smarty->php_handling = SMARTY_PHP_QUOTE;
        $this->Smarty->plugins_dir = SMARTY_DIR.'plugins';
        $this->Smarty->request_use_auto_globals = false;
        //$this->Smarty->request_vars_order = 'EGPCS';
        $this->Smarty->right_delimiter = '}';
        $this->Smarty->use_sub_dirs = true;
    }
    /**
     * function SetViewTemplate
     *
     * This method sets the appropriate template to display to the user.
     *
     * @access public
     */
    private function SetViewTemplate() {
        switch($this->Request->HTTP_GET['template']) {
            case "gazetteer":
                $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates/gazetteer';
                $this->Smarty->assign('STYLESHEET_PATH', '/phpwebtk/sampleview/templates/gazetteer/');
                $this->Smarty->display('gazetteer.xhtml');
                break;
            case "gila":
                $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates/gila';
                $this->Smarty->assign('STYLESHEET_PATH', '/phpwebtk/sampleview/templates/gila/');
                $this->Smarty->display('gila.xhtml');
                break;
            case "gila_edit_form":
                $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates/gila';
                $this->Smarty->assign('STYLESHEET_PATH', '/phpwebtk/sampleview/templates/gila/');
                $this->Smarty->display('gila_edit_form.xhtml');
                break;
            case "prosimii":
                $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates/prosimii';
                $this->Smarty->assign('STYLESHEET_PATH', '/phpwebtk/sampleview/templates/prosimii/');
                $this->Smarty->display('prosimii.xhtml');
                break;
            case "sinorca":
                $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates/sinorca';
                $this->Smarty->assign('STYLESHEET_PATH', '/phpwebtk/sampleview/templates/sinorca/');
                $this->Smarty->display('sinorca.xhtml');
                break;
            case "tierraverde":
                $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates/tierraverde';
                $this->Smarty->assign('STYLESHEET_PATH', '/phpwebtk/sampleview/templates/tierraverde/');
                $this->Smarty->display('tierraverde.xhtml');
                break;
            default:
                $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates';
                $this->Smarty->display('index.xhtml');
                break;
        }
    }
    /**
     * function Display
     *
     * This method displays the complete view to the user.
     *
     * @access public
     * @static
     */
    public function Display() {
        $this->SetSmartyCaching();
        $this->SetSmartyCompiler();
        $this->SetSmartyConfiguration();
        $this->SetSmartyDebugging();
        $this->SetSmartyFilters();
        $this->SetSmartySecurity();
        $this->SetSmartyMiscellaneous();
       if (isset($this->Request->HTTP_GET['template'])) {
            $this->SetViewTemplate();
        } else {
            $this->Smarty->template_dir = CLASS_PATH.'sampleview/templates';
            $this->Smarty->display('index.xhtml');
        }
    }
}
?>