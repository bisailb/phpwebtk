<?php
/**
 * $Id: convert.class.php,v 1.4 2004/11/23 14:17:32 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.3 Alpha
 *
 * @package phpwebtk
 */
/**
 * class Convert
 *
 * This class provides some common data conversion functions.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage conversion
 */
class Convert {
    // Private members
    private static $Convert;
    /**
     * function GetInstance
     *
     * This method instantiates a new object from this class; more
     * specifically, it's a singleton instance.
     *
     * @access public
     * @static
     * @return Convert object instance
     */
    public static function GetInstance() {
        $Convert = null;
        if (empty(Convert::$Convert)) {
            Convert::$Convert = new Convert();
        }
        return(Convert::$Convert);
    }
    /**
     * function Hex2Bin
     *
     * This method converts hexadecimal data into a binary
     * representation.
     *
     * @access public
     * @param hexData Hexadecimal encoded data
     * @return string Binary encoded data
     */
    public function Hex2Bin($hexData) {
        $length = strlen($hexData);
        return(pack('H' . $length, $hexData));
    }
}
?>