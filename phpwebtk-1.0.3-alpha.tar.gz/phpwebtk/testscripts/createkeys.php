<?php
$start = microtime(1);
require_once('../configuration/constants.php');
function __autoload($class) {
    require_once(CLASS_PATH . strtolower($class) . '.class.php');
}
ob_start();
$Hmac = Hmac::GetInstance();
$Crypt = Crypt::GetInstance();
$Hmac->SetHmacKey('foo');
$Crypt->SetEncryptionKey($Hmac->GetHmac('bar'));
ob_end_flush();
$stop = microtime(1);
$time = $stop - $start;
print('Time Elapsed: ' . $time);
?>