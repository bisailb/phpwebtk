<?php
/**
 * $Id: daofactory.class.php,v 1.5 2004/11/23 14:17:33 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.3 Alpha
 *
 * @package phpwebtk
 */
/**
 * class DaoFactory
 *
 * This class declares an interface for operations that create abstract
 * Data Access Objects (DAOs).
 *
 * @abstract
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage databases
 */
abstract class DaoFactory {
    // Abstract methods
    public abstract function GetSampleDao();
    /**
     * function GetDaoFactory
     *
     * This method builds a Data Source Name (DSN) and invokes the
     * appropriate DAO Factory with the DSN as a parameter.
     *
     * @access public
     * @static
     * @return mixed object instance|FALSE
     */
    public static function GetDaoFactory() {
        $XmlDaoFactory = XmlDaoFactory::GetInstance();
        $DomDocument = $XmlDaoFactory->LoadXmlFile(CONFIG_FILE, SCHEMA_FILE);
        $XmlConfigDao = $XmlDaoFactory->GetXMLDao($DomDocument);
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/driver');
        $driver = $elementList['driver'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/username');
        $username = $elementList['username'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/password');
        $password = $elementList['password'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/hostname');
        $hostname = $elementList['hostname'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/database');
        $database = $elementList['database'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/persistent');
        $persistent = $elementList['persistent'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/debug');
        $debug = $elementList['debug'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/fetchmode');
        $fetchmode = $elementList['fetchmode'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/clientflags');
        $clientflags = $elementList['clientflags'];
        $elementList = $XmlConfigDao->GetElementsByPath('//mysql/socket');
        $socket = $elementList['socket'];
        $dsn = "$driver://$username:$password@$hostname/$database?persistent=$persistent&debug=$debug&fetchmode=$fetchmode&clientflags=$clientflags&socket=$socket";
        switch($driver) {
            case 'mysql':
                return(new MysqlDaoFactory($dsn));
                break;
            case 'mysqli':
                return(new MysqliDaoFactory($dsn));
                break;
            case 'mysqlt':
                return(new MysqltDaoFactory($dsn));
                break;
            default:
                return(FALSE);
                break;
        }
    }
}
?>