<?php
/**
 * $Id: request.class.php,v 1.3 2004/11/23 14:17:49 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.3 Alpha
 *
 * @package phpwebtk
 */
/**
 * class Request
 *
 * This class represents the complex Request object under construction.
 * The RequestBuilder builds the Request object's internal
 * representation and defines the process by which it's assembled. This
 * class includes classes that define the constituent parts, includng
 * interfaces for assembling the parts into the final result.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage http
 */
class Request {
    // Private members
    private static $Request;
    /**
     * function GetInstance
     *
     * This method instantiates a new object from this class; more
     * specifically, it's a singleton instance.
     *
     * @access public
     * @static
     * @return Request object instance
     */
    public static function GetInstance() {
        $Request = null;
        if (TRUE !== Request::$Request) {
            Request::$Request = new Request();
        }
        return(Request::$Request);
    }
    /**
     * function SetProperty
     *
     * This method sets dynamic properties of this class.
     *
     * @access public
     * @static
     */
    public function SetProperty($propertyName, $requestPart) {
        $this->{$propertyName} = $requestPart;
    }
}
?>