<?php
require_once('configuration/constants.php');
function __autoload($class) {
    require_once(CLASS_PATH . strtolower($class) . '.class.php');
}
$Client = Client::GetInstance();
$Client->SendRequest();
?>