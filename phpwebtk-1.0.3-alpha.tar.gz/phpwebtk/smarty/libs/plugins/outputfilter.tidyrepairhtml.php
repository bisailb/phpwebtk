<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */

/**
 * Smarty tidyrepairhtml outputfilter plugin
 *
 * File:     outputfilter.tidyrepairhtml.php<br>
 * Type:     outputfilter<br>
 * Name:     tidyrepairhtml<br>
 * Date:     November 22, 2004<br>
 * Purpose:  clean and repair HTML source
 * Install:  Drop into the plugin directory, call
 *           <code>$smarty->load_filter('output','tidyrepairhtml');</code>
 *           from application.
 * @author   Brian Bisaillon <bbisaillon@users.sourceforge.net>
 * @version  1.0
 * @param string
 * @param Smarty
 */
function smarty_outputfilter_tidyrepairhtml($source, &$smarty) {
    if (extension_loaded('tidy')) {
        $Tidy = new Tidy();
        $Tidy->parseString($source);
        $Tidy->cleanRepair();
    }
    $Exception = null;
    try {
        if(!empty($Tidy->errorBuffer)) {
            throw new Exception("<h1>\n  Parser Errors or Warnings\n</h1>\n<strong>Warning: </strong> smarty_outputfilter_tidyrepairhtml(): " . trim(htmlentities("{$Tidy->errorBuffer}")) . ': Smarty.plugins.Exception <strong>');
        }
    }
    catch (Exception $Exception) {
        PException::Display($Exception);
    }
    return $source;
}

?>