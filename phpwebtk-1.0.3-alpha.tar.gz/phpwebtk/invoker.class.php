<?php
/**
 * $Id: invoker.class.php,v 1.2 2004/11/23 14:17:49 bbisaillon Exp $
 * PHP Web Toolkit Version 1.0.3 Alpha
 *
 * @package phpwebtk
 */
/**
 * class Invoker
 *
 * This class asks the command to carry out the request.
 *
 * @author Brian Bisaillon <bisailb@myprivacy.ca>
 * @copyright Copyright (C) 2004 by Brian Bisaillon
 * @package phpwebtk
 * @subpackage http
 */
class Invoker {
    // Private members
    private static $Invoker;
    private $Command;
    /**
     * function GetInstance
     *
     * This method instantiates a new object from this class; more
     * specifically, it's a singleton instance.
     *
     * @access public
     * @static
     * @return Invoker object instance
     */
    public static function GetInstance() {
        $Invoker = null;
        if (TRUE !== Invoker::$Invoker) {
            Invoker::$Invoker = new Invoker();
        }
        return(Invoker::$Invoker);
    }
    /**
     * function SetCommand
     *
     * This method sets the command.
     *
     * @access private
     */
    public function SetCommand(Command $Command) {
        $this->Command = $Command;
    }
    /**
     * function SetCommand
     *
     * This method executes the command and returns the result to the
     * receiver.
     *
     * @access private
     */
    public function ExecuteCommand(Request $Request) {
        $result = $this->Command->Execute($Request);
        return($result);
    }
}
?>